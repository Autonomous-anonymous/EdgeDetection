"""Run the curved JARCRAC summit course from a Camino checkout."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile


def main():
    args = sys.argv[1:]
    if args in (["-h"], ["--help"]):
        print("Run from the Camino summit checkout.\n"
              "  python3 camino-summit-climb.zip [demo] [--out DIRECTORY] [--headless]\n"
              "  python3 camino-summit-climb.zip loop [--laps N] [--out DIRECTORY]\n"
              "  python3 camino-summit-climb.zip prepare WORLD.sdf\n"
              "  python3 camino-summit-climb.zip replay [--obstacle STATION_M OFFSET_M]\n"
              "Use 'demo --help' for all lap options. A fresh output directory is created by default.")
        return 0
    if not args or args[0].startswith("-"):
        args = ["demo", *args]
    source = Path.cwd() / "edge-path-project/gazebo/scripts"
    requires = ("jarcrac_compact_sil.py", "jarcrac_convoy_score.py", "jarcrac_showcase_scene.py")
    if not all((source / name).is_file() for name in requires):
        print("Run from your Camino checkout, for example ~/camino-summit-test.", file=sys.stderr)
        return 2
    if args[0] in ("demo", "loop") and not any(
            opt == "--out" or opt.startswith("--out=") for opt in args) and not {"-h","--help"}.intersection(args):
        root = Path(tempfile.mkdtemp(prefix="camino-summit-climb-"))
        args.extend(["--out", str(root / ("lap" if args[0] == "demo" else "laps"))])
    with tempfile.TemporaryDirectory(prefix="camino-summit-code-") as folder:
        code = Path(folder)
        with zipfile.ZipFile(Path(sys.argv[0]).resolve()) as archive:
            for name in archive.namelist():
                entry = Path(name)
                if entry.parent.as_posix() == "src" and entry.suffix == ".py":
                    (code / entry.name).write_bytes(archive.read(name))
            script = "jarcrac_summit_trial.py"
            if args[0] == "replay":
                script = "replay_summit.py"
                (code / script).write_bytes(archive.read("tests/"+script))
                args = args[1:]
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        env["PYTHONPATH"] = os.pathsep.join(filter(None, (str(code), str(source), env.get("PYTHONPATH"))))
        try:
            return subprocess.run([sys.executable, "-u", str(code / script), *args],
                                  env=env).returncode
        except KeyboardInterrupt:
            return 130


if __name__ == "__main__":
    raise SystemExit(main())
