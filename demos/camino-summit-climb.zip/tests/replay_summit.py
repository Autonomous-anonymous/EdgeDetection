"""Closed-loop kinematic check of the curved summit course using synthetic front ranges."""
import argparse
import json
import math
from types import SimpleNamespace

import numpy as np
from scipy.ndimage import map_coordinates

from jarcrac_convoy_v2 import launch_space
from jarcrac_cooperative_control import State
from jarcrac_cooperative_geometry import model_footprints, rotate
from jarcrac_cooperative_terrain import (FRONT_SENSOR, HALF_STEP, HORIZONTAL_SAMPLES, VERTICAL_SAMPLES,
                                        WORLD_FRAME, beam_vectors, scan_from_message, spawn_pose)
from jarcrac_summit_mission import SUMMIT, SummitMission, summit_terrain
from jarcrac_summit_scene import DEFAULT_STUMP
from jarcrac_summit_score import Score, STUMP_HEIGHT, STUMP_RADIUS, stump_outline


class RayFixture:
    def __init__(self, terrain, route, stump, seed):
        self.rng = np.random.default_rng(seed)
        self.stump = stump
        xs, ys = zip(*route.points)
        self.xmin, self.ymin = min(xs)-11., min(ys)-11.
        self.pitch = .12
        self.mesh = np.array([
            [terrain.height_at(x, y) for x in np.arange(self.xmin, max(xs)+11., self.pitch)]
            for y in np.arange(self.ymin, max(ys)+11., self.pitch)], dtype=float)
        self.floor = min(terrain.height_at(x,y) for x,y in (*stump_outline(*stump), stump))-.015
        self.top = self.floor+STUMP_HEIGHT
        self.h0, self.dh = -math.pi/2+HALF_STEP, math.pi/(HORIZONTAL_SAMPLES-1)
        self.v0, self.dv = -math.pi/12, math.pi/6/(VERTICAL_SAMPLES-1)
        self.beams = np.array(beam_vectors(self.h0, self.dh, self.v0, self.dv))

    def ranges(self, vehicle):
        axes = np.array([rotate(axis, vehicle.roll, vehicle.pitch, vehicle.yaw) for axis in np.eye(3)])
        dx, dy, dz = (self.beams@axes).T
        ox, oy, oz = np.array(rotate(FRONT_SENSOR, vehicle.roll, vehicle.pitch, vehicle.yaw)) + np.array(
            (vehicle.x, vehicle.y, vehicle.z))
        step = .24
        ray = np.arange(.1, 10.35, step).reshape(-1,1)
        xs, ys = ox+ray*dx, oy+ray*dy
        ground = map_coordinates(self.mesh, [(ys-self.ymin)/self.pitch, (xs-self.xmin)/self.pitch],
                                 order=1, mode="constant", cval=np.nan, prefilter=False)
        above = oz+ray*dz-ground
        hits = above <= 0.
        first = hits.argmax(axis=0)
        j = np.arange(len(dx))
        lower = np.maximum(first-1, 0)
        drop = above[lower,j]-above[first,j]
        fraction = np.zeros(len(dx))
        np.divide(above[lower,j]*step, drop, where=drop>0, out=fraction)
        ranges = np.where(hits.any(axis=0),
                          np.where(first>0, ray[lower,0]+fraction, ray[first,0]), math.inf)
        # Intersect the solid cylinder and keep the nearer of the ground and stump.
        x, y = ox-self.stump[0], oy-self.stump[1]
        radial = dx*dx+dy*dy
        dot = x*dx+y*dy
        disc = dot*dot-radial*(x*x+y*y-STUMP_RADIUS**2)
        root = np.sqrt(np.maximum(0., disc))
        enter, leave = (-dot-root)/radial, (-dot+root)/radial
        with np.errstate(divide="ignore", invalid="ignore"):
            zlow, zhigh = (self.floor-oz)/dz, (self.top-oz)/dz
        level = np.abs(dz)<1e-12
        z_enter = np.where(level, -math.inf, np.minimum(zlow, zhigh))
        z_leave = np.where(level, math.inf if self.floor<=oz<=self.top else -math.inf, np.maximum(zlow, zhigh))
        enter = np.maximum(0., np.maximum(enter,z_enter))
        leave = np.minimum(leave,z_leave)
        np.minimum(ranges, np.where((disc>=0)&(enter<=leave), enter, math.inf), out=ranges)
        finite = np.isfinite(ranges)
        ranges[finite] += self.rng.normal(0., .015, finite.sum())
        ranges[ranges<.3] = -math.inf
        return SimpleNamespace(count=HORIZONTAL_SAMPLES, vertical_count=VERTICAL_SAMPLES, ranges=ranges,
                               angle_min=self.h0, angle_step=self.dh, vertical_angle_min=self.v0,
                               vertical_angle_step=self.dv, range_min=.3, range_max=30.)


def advance(pose, command, brakes, dt, terrain, yaw_response):
    def approach(value, target, change):
        return value+math.copysign(min(abs(target-value), change), target-value)

    forward = pose.vx*math.cos(pose.yaw)+pose.vy*math.sin(pose.yaw)
    speed = approach(forward, command.speed, brakes.deceleration*dt)
    omega = approach(pose.omega, command.yaw_rate*yaw_response, brakes.angular_deceleration*dt)
    yaw = pose.yaw+omega*dt
    c, s = math.cos(yaw), math.sin(yaw)
    vx, vy = speed*c, speed*s
    x, y = pose.x+vx*dt, pose.y+vy*dt

    def h(u,v):
        return terrain.height_at(x+c*u-s*v, y+s*u+c*v)

    return State(pose.stamp+dt, x, y, yaw, vx, vy, omega,
                 roll=math.atan2(h(0.,.8)-h(0.,-.8),1.6),
                 pitch=-math.atan2(h(1.,0.)-h(-1.,0.),2.), z=h(0.,0.)+.035)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--obstacle", type=float, nargs=2, default=DEFAULT_STUMP, metavar=("STATION_M","OFFSET_M"))
    parser.add_argument("--yaw-response", type=float, default=1.)
    parser.add_argument("--seed", type=int, default=811)
    args = parser.parse_args()
    if not all(map(math.isfinite,args.obstacle)) or not 0. < args.yaw_response <= 2.:
        parser.error("Specify a finite stump position and a yaw response above zero and at most two.")
    route, terrain, shape = SUMMIT.route, summit_terrain(), model_footprints()[0]
    wx, wy = route.world(*args.obstacle)
    fixture = RayFixture(terrain, route, (wx,wy), args.seed)
    obstacle = State(1., wx, wy, z=fixture.floor+STUMP_HEIGHT/2)
    x,y,z,roll,pitch,yaw = spawn_pose(terrain, shape, SUMMIT.start(0), 0., SUMMIT.frame)
    vehicle = State(1., x, y, yaw, roll=roll, pitch=pitch, z=z)
    mission, score, space = SummitMission(shape, terrain=terrain), Score(shape), launch_space(SUMMIT)
    dt = .05
    hold_verified = False
    for i in range(round(SUMMIT.sim_timeout/dt)+1):
        if i%2 == 0:
            scan = scan_from_message(fixture.ranges(vehicle), vehicle.stamp, vehicle, terrain, WORLD_FRAME)
            observed = space.update(scan, vehicle) if scan else None
        decision = mission.step(vehicle.stamp, vehicle, observed)
        score.observe(vehicle, obstacle)
        hold_verified |= (mission.navigator.phase == "detour" and decision.a.speed > 0
                          and mission.navigator.completed_hold_seconds >= 5.)
        if mission.done:
            break
        vehicle = advance(vehicle, decision.a, mission.navigator.brakes, dt, terrain, args.yaw_response)
    result = score.result()
    passed = bool(mission.done and result["geometry_passed"] and hold_verified)
    print(json.dumps({"method":"kinematic_replay", "passed":passed, "a_controller_hold_verified":hold_verified,
                      "obstacle_station_offset_m":args.obstacle, "yaw_response":args.yaw_response,
                      **result}, indent=2, allow_nan=False))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
