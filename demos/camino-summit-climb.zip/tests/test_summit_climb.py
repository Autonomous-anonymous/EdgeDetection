"""Regression checks for measured tilt, the rear blind spot and the curved route."""
from dataclasses import replace
import math
import unittest

from jarcrac_convoy_v2 import launch_space
from jarcrac_cooperative_control import State, STOP
from jarcrac_cooperative_geometry import model_footprints
from jarcrac_cooperative_terrain import FrontScan
from jarcrac_summit_mission import SUMMIT, SummitMission, summit_terrain
from jarcrac_summit_score import Score
from jarcrac_summit_trial import timeout_reason


def view(stamp, pose, along, obstruction=math.inf):
    return FrontScan(stamp, pose.x+along*math.cos(pose.yaw), pose.y+along*math.sin(pose.yaw),
                     pose.yaw, (10.,)*181, (obstruction,)*181)


class SummitChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.shape = model_footprints()[0]
        cls.terrain = summit_terrain()

    def setUp(self):
        self.mission = SummitMission(self.shape, terrain=self.terrain)
        self.pose = State(2., *SUMMIT.route.at(12.))
        self.space = launch_space(SUMMIT)

    def test_padded_rear_requires_positive_observation(self):
        pose, space = self.pose, self.space
        space.update(view(2., pose, 1.68), pose)
        nav = self.mission.navigator
        self.assertFalse(nav.clear_at(space, pose.x, pose.y, pose.yaw))
        reason = nav.rejected_checks[-1]
        self.assertEqual(reason["reason"], "lidar_unobserved")
        self.assertLess(reason["body_xy"][0], -2.4)
        self.assertLess(reason["body_xy"][1], -1.8)
        nav.phase = "follow"
        self.assertEqual(self.mission.step(2., pose, space).a, STOP)
        self.assertEqual(nav.stop_reason, "stopping_space_unverified")

    def test_recent_positive_view_and_new_obstruction(self):
        pose, space = self.pose, self.space
        space.update(view(1.9, pose, -6.), pose)
        space.update(view(2., pose, 1.68), pose)
        nav = self.mission.navigator
        self.assertTrue(nav.clear_at(space, pose.x, pose.y, pose.yaw))
        space.update(view(2.1, pose, -6., obstruction=1.), pose)
        self.assertFalse(nav.clear_at(space, pose.x, pose.y, pose.yaw))
        self.assertEqual(nav.rejected_checks[-1]["reason"], "lidar_obstruction")

    def test_measured_pitch_and_stale_scan_stop_motion(self):
        self.mission.navigator.phase = "follow"
        self.space.update(view(2., self.pose, -6.), self.pose)
        unsafe = replace(self.pose, pitch=math.radians(-9.15728))
        self.assertEqual(self.mission.step(2., unsafe, self.space).a, STOP)
        self.assertEqual(self.mission.step(2.35, replace(self.pose, stamp=2.35), self.space).a, STOP)
        self.assertEqual(self.mission.navigator.stop_reason, "state_or_scan_unavailable")

    def test_peak_on_an_intermediate_pose_counts(self):
        score = Score(self.shape)
        start = State(1., *SUMMIT.route.at(0.), z=28.)
        stump = State(1., *SUMMIT.route.world(10.5, -.12))
        score.observe(start, stump)
        score.observe(replace(start, stamp=1.04, pitch=math.radians(-9.15728)), stump)
        score.observe(replace(start, stamp=1.10), stump)
        result = score.result()
        self.assertTrue(result["tilt_violation"])
        self.assertFalse(result["geometry_passed"])
        self.assertAlmostEqual(result["max_abs_pitch_deg"], 9.15728)

    def test_curve_station_and_deadlines(self):
        route = SUMMIT.route
        for i in range(101):
            s = route.length*i/100.
            station, offset = route.local(*route.world(s))
            self.assertAlmostEqual(station, s, places=5)
            self.assertAlmostEqual(offset, 0., places=5)
        self.assertTrue(timeout_reason(150.104, .1, 0.).startswith("simulation_time_limit"))
        self.assertTrue(timeout_reason(12., .1, 8.1).startswith("clock_stalled"))


if __name__ == "__main__":
    unittest.main()
