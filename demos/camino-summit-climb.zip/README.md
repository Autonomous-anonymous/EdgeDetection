# Camino JARCRAC summit climb

Run one Gazebo Harmonic lap from the root of the Camino summit checkout based on `8995c421`. The launcher reads the Ruskotunturi collision mesh and detailed JARCRAC model from the checkout and loads the summit-specific Python files from this archive.

```bash
cd ~/camino-summit-test
python3 camino-summit-climb.zip
```

The GUI opens for a single lap. The default physics step is 0.002 s and the target RTF is 1.5. Each run gets a fresh output directory with `result.json`, independent `evaluation.json`, timestamped `control.jsonl` and a compact `summit-reports.zip`. The GUI includes the goal ring, route markings and Visualize Lidar. If the scan display needs a topic, refresh the Visualize Lidar topic list and select `/camino/cooperative/a/lidar`.

```bash
python3 camino-summit-climb.zip demo --physics-step 0.002 --target-rtf 1.5 --wall-timeout 900
python3 camino-summit-climb.zip loop --laps 3
```

The lap has a 150 s simulated deadline and a five-minute exhibition wall-time criterion. The loop ends on the first failed lap. Omit `--laps` for a continuous loop. Use `demo --help` for headless operation and custom output or stump placement. Stump coordinates are distance along the curved route and signed lateral offset, both in metres. World coordinates and these route coordinates are recorded in the trace.

## Course and evaluation

The 27 m reference line runs from world XY (−71.77, −150.04) to an interior crest at (−78.00, −169.00). The vehicle settles at launch and accelerates gradually. The controller derives a bypass from repeated stationary LiDAR returns. It tests the entire candidate against the 5 × 5 ground profile, corridor boundaries, curvature and observed stump cluster. Before each motion command it checks the padded footprint over the measured stopping envelope and the commanded arc using current and recent raw-range evidence.

The evaluator reads Gazebo model poses independently. It measures actual tilt from the first available vehicle poses, full-body clearance to the stump, stationary hold, aligned forward travel along the curve and parked elevation gain. Acceptance requires at least 1 m clearance, a five-second stop, at least 1.5 m and five seconds of aligned travel after bypass, at least 1.2 m of elevation gain and a parked arrival. Either roll or pitch above 8° fails the lap.

## Reproduce the offline check

The optional replay requires NumPy and SciPy. It generates 721 × 32 front ranges at 10 Hz from sampled collision-mesh terrain and a cylinder, adds seeded 15 mm range noise, and closes the loop through the actual summit controller and independent scorer at 20 Hz. Its kinematic model estimates attitude from ground heights. Gazebo track contact and chassis pitch require a desktop lap.

```bash
python3 camino-summit-climb.zip replay
python3 camino-summit-climb.zip replay --obstacle 11.15 0.12 --yaw-response 0.84
```

| Replay | Duration | Maximum absolute pitch | Maximum absolute roll | Minimum stump gap | Stationary hold | Verified aligned travel | Parked gain |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Default stump | 106.3 s | 6.52° | 4.64° | 1.93 m | 5.4 s | 1.52 m in 6.0 s | 2.02 m |
| Shifted stump, reduced yaw response | 107.6 s | 6.85° | 4.90° | 2.03 m | 5.3 s | 1.51 m in 6.3 s | 2.02 m |
