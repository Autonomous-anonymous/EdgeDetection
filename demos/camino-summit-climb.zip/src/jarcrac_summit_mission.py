"""Front-LiDAR navigation on the surveyed summit approach. All footprint checks use world coordinates."""
from dataclasses import dataclass
from itertools import chain
import math
from types import SimpleNamespace

from jarcrac_convoy_v2 import StaticEvidence, stationary
from jarcrac_cooperative_control import (AGE_LIMIT, HOLD_SECONDS, PATH_CURVATURE_LIMIT, STOP, TILT_LIMIT,
                                        Decision, ObstacleNavigator, angle_error, tracked_command)
from jarcrac_cooperative_terrain import BIN_STEP
from jarcrac_summit_route import GroundProfile, Polyline, SUMMIT, summit_terrain


def observe_contacts(front):
    for i, r in enumerate(front.hazard):
        if math.isfinite(r):
            yaw = front.yaw-math.pi/2+i*BIN_STEP
            yield front.x+r*math.cos(yaw), front.y+r*math.sin(yaw)


def join_curve(start, end, start_yaw, end_yaw, start_scale, end_scale):
    """Cubic Hermite in world metres. Exclude the end to join adjacent segments."""
    length = math.dist(start, end)
    count = max(2, math.ceil(length/.14))
    for i in range(count):
        t = i/count
        w = t*t*(3.-2.*t)
        da = length*start_scale*t*(1.-t)**2
        db = -length*end_scale*t*t*(1.-t)
        yield ((1.-w)*start[0]+w*end[0]+da*math.cos(start_yaw)+db*math.cos(end_yaw),
               (1.-w)*start[1]+w*end[1]+da*math.sin(start_yaw)+db*math.sin(end_yaw))


@dataclass
class Bypass:
    path: Polyline
    return_start: float
    return_end: float
    offset: float


class SummitNavigator(ObstacleNavigator):
    def __init__(self, shape, course, terrain):
        super().__init__(shape, padding=.62, cruise=course.a_speed)
        self.padded_radius = max(math.hypot(u, v) for u, v in self.padded_samples)
        self.course, self.route = course, course.route
        self.ground = GroundProfile(shape, terrain)
        self.phase = "settle"
        self.bypass = None
        self.rejected_checks = []
        self.launch_since = self.motion_since = self.park_since = None
        self.done = False
        self.evidence = StaticEvidence()
        self.last_plan_time = -math.inf

    def reject(self, reason, **values):
        self.rejected_checks.append({"reason": reason, **values})
        return False

    def ground_clear(self, x, y, yaw, check):
        slopes = self.ground.slopes(x, y, yaw)
        if slopes is None:
            return self.reject("terrain_unmapped", check=check, world_xy=(x, y))
        if max(slopes) > math.radians(7.9):
            return self.reject("terrain_tilt", check=check, world_xy=(x, y),
                               pitch_chord_deg=math.degrees(slopes[0]),
                               roll_chord_deg=math.degrees(slopes[1]))
        return True

    def route_contains(self, x, y, yaw):
        c, n = math.cos(yaw), math.sin(yaw)
        # Distance to the route can increase by no more than the footprint
        # radius. The endpoint tangents bound extensions before and after the route.
        radius = self.padded_radius
        sx, sy = self.route.points[0]
        gx, gy = self.route.points[-1]
        ux, uy = self.route.tangents[0]
        vx, vy = self.route.tangents[-1]
        _, center_d = self.route.local(x, y)
        inside = (abs(center_d)+radius <= self.course.half_width
                  and (x-sx)*ux+(y-sy)*uy-radius >= -3.4
                  and (x-gx)*vx+(y-gy)*vy+radius <= 3.4)
        if inside:
            return True
        for u, v in self.padded_samples:
            wx, wy = x+c*u-n*v, y+n*u+c*v
            station, offset = self.route.local(wx, wy)
            if not -3.4 <= station <= self.route.length+3.4 or abs(offset) > self.course.half_width:
                return self.reject("route_boundary", world_xy=(wx, wy), body_xy=(u, v),
                                   station=station, offset=offset)
        return True

    def clear_at(self, scan, x, y, yaw, *, samples=None):
        if not self.ground_clear(x, y, yaw, "footprint") or not self.route_contains(x, y, yaw):
            return False
        c, n = math.cos(yaw), math.sin(yaw)
        for u, v in self.padded_samples if samples is None else samples:
            wx, wy = x+c*u-n*v, y+n*u+c*v
            if not scan.covers(wx, wy):
                seen = next((b for f in chain((scan.current,), scan.frames)
                             if (b := f.verdict(wx, wy)) is not None), None)
                s, d = self.route.local(wx, wy)
                return self.reject("lidar_obstruction" if seen is False else "lidar_unobserved",
                                   world_xy=(wx, wy), body_xy=(u, v), station=s, offset=d)
        return True

    def make_bypass(self, state, obstacle_s, pass_d, lead, release, end_distance):
        # Pass the sighted obstacle along its route tangent. Following a parallel
        # offset around an inside bend can force an unnecessarily sharp rear swing.
        end = obstacle_s+end_distance
        if end > self.route.length-2.1:
            return None
        ax, ay = self.route.world(obstacle_s, pass_d)
        _, _, tangent = self.route.at(obstacle_s)
        tx, ty = math.cos(tangent), math.sin(tangent)
        enter = ax-lead*tx, ay-lead*ty
        leave = ax+release*tx, ay+release*ty
        ex, ey, end_yaw = self.route.at(end)
        points = list(join_curve((state.x,state.y), enter, state.yaw, tangent, 1.4, 1.))
        count = math.ceil((lead+release)/.14)
        points.extend((enter[0]+(leave[0]-enter[0])*i/count,
                       enter[1]+(leave[1]-enter[1])*i/count) for i in range(count))
        points.extend(join_curve(leave, (ex,ey), tangent, end_yaw, 1., 1.4))
        count = math.ceil((self.route.length-end)/.15)
        points.extend(self.route.world(end+(self.route.length-end)*i/count) for i in range(count+1))
        return Bypass(Polyline(points), self.route.local(*leave)[0], end, pass_d)

    def clears_observed_cluster(self, poses, contacts):
        (x0, x1), (y0, y1) = self.padded_bounds
        for x, y, yaw in poses:
            c, n = math.cos(yaw), math.sin(yaw)
            for wx, wy in contacts:
                dx, dy = wx-x, wy-y
                if dx*dx+dy*dy > (self.padded_radius+.55)**2:
                    continue
                u, v = c*dx+n*dy, -n*dx+c*dy
                gap = math.hypot(max(x0-u, 0., u-x1), max(y0-v, 0., v-y1))
                if gap < .55:
                    return self.reject("observed_cluster_margin", check="bypass", world_xy=(x,y),
                                       observed_world_xy=(wx,wy), padded_gap_m=gap)
        return True

    def select_bypass(self, state, space):
        obstacle_s, obstacle_d = self.evidence.points[-1][1]
        first_side = -1. if obstacle_d >= 0. else 1.
        face = self.route.world(obstacle_s, obstacle_d)
        contacts = [point for point in observe_contacts(space.current) if math.dist(point, face) < 1.]
        if not contacts:
            return self.reject("cluster_unobserved", check="bypass")
        for width in (3.20, 3.40, 2.95):
            for side in (first_side, -first_side):
                for lead, release, end_distance in ((1., 1.9, 10.), (1.6, 1.9, 11.5), (.5, 1.3, 8.8)):
                    candidate = self.make_bypass(state, obstacle_s, obstacle_d+side*width,
                                                 lead, release, end_distance)
                    if not candidate:
                        continue
                    path = candidate.path
                    limit = path.length
                    step = .25
                    turns = [path.at(min(i*step, limit)) for i in range(math.ceil(limit/step)+1)]
                    if any(abs(angle_error(b[2], a[2])) > PATH_CURVATURE_LIMIT*step
                           for a, b in zip(turns, turns[1:])):
                        self.reject("curvature_limit", check="bypass")
                        continue
                    if not self.clears_observed_cluster(turns, contacts):
                        continue
                    if not all(self.ground_clear(x, y, a, "bypass") and self.route_contains(x, y, a)
                               for x, y, a in turns):
                        continue
                    # Visibility around an obstacle grows as the sensor moves.
                    # Verify an initial prefix now and every commanded stop sweep afterwards.
                    if all(self.clear_at(space, *path.at(i*.25)) for i in range(9)):
                        self.bypass = candidate
                        return True
        return False

    def stop(self, reason):
        self.stop_reason = reason
        self.motion_since = None
        return STOP

    def interrupt(self, reason):
        self.launch_since = self.park_since = self.stopped_since = None
        self.evidence.reset()
        self.rejected_checks.clear()
        return self.stop(reason)

    def checked_motion(self, now, vehicle, space, path):
        progress, _ = path.local(vehicle.x, vehicle.y)
        remaining = path.length-progress
        x, y, _ = path.at(min(path.length, progress+.85))
        distance = math.hypot(x-vehicle.x, y-vehicle.y)
        error = angle_error(math.atan2(y-vehicle.y, x-vehicle.x), vehicle.yaw)
        if distance < .02 or abs(error) > 1.15:
            return self.stop("tracking_heading_unverified")
        curvature = 2.*math.sin(error)/distance
        if abs(curvature) > PATH_CURVATURE_LIMIT:
            self.reject("curvature_limit", check="command", curvature=curvature)
            return self.stop("path_clearance_unverified")
        if self.motion_since is None:
            self.motion_since = now
        tilt = math.degrees(max(abs(vehicle.roll), abs(vehicle.pitch)))
        grade_speed = self.cruise-.095*max(0., min(1., (tilt-6.)/1.5))
        speed = min(grade_speed, .035+.11*(now-self.motion_since), max(.045, .55*remaining))
        command = tracked_command(speed, curvature)
        if not self.stopping_space_clear(vehicle, space):
            return self.stop("stopping_space_unverified")
        # Verify the actual commanded arc, including a complete braking distance
        # and rotation allowance, before sending even the first positive command.
        check_length = max(.65, self.brakes.distance(vehicle, command)+.27)
        steps = math.ceil(check_length/.12)
        for i in range(1, steps+1):
            along = check_length*i/steps
            theta = curvature*along
            yaw = vehicle.yaw+theta
            chord = along if abs(theta) < 1e-8 else 2.*math.sin(theta/2.)/curvature
            cx = vehicle.x+chord*math.cos(vehicle.yaw+theta/2.)
            cy = vehicle.y+chord*math.sin(vehicle.yaw+theta/2.)
            if not self.clear_at(space, cx, cy, yaw):
                return self.stop("path_clearance_unverified")
        self.stop_reason = None
        return command

    def tick(self, now, vehicle, space):
        self.rejected_checks.clear()
        if now is None or vehicle is None or not vehicle.fresh(now, TILT_LIMIT):
            return self.interrupt("stale_or_excessive_tilt")
        if space is None or not -.02 <= now-space.stamp <= AGE_LIMIT:
            return self.interrupt("state_or_scan_unavailable")
        here = self.route.state(vehicle)
        if self.phase == "settle":
            if not stationary(vehicle):
                self.launch_since = None
            elif self.launch_since is None:
                self.launch_since = now
            if self.launch_since is None or now-self.launch_since < 1.25:
                return self.stop("settling_at_launch")
            self.phase = "follow"

        if self.bypass is None:
            front = space.current
            self.evidence.update(SimpleNamespace(stamp=front.stamp, contacts=observe_contacts(front)),
                                 here, self.route, None)
            hit = self.evidence.points[-1][1] if self.evidence.points else None
            if self.phase == "follow" and hit and hit[0]-here.x <= 8.9:
                self.phase = "brake"
            if self.phase in ("brake", "wait"):
                if not stationary(vehicle):
                    self.stopped_since = None
                    return self.stop("braking_for_obstacle")
                self.phase = "wait"
                if self.stopped_since is None:
                    self.stopped_since = now
                if now-self.stopped_since < HOLD_SECONDS+.20:
                    return self.stop("stationary_obstacle_hold")
                if not hit:
                    # A departing obstacle may expose the route. checked_motion
                    # still verifies current ranges before forward travel.
                    self.phase, self.stopped_since = "follow", None
                elif self.evidence.confirmed:
                    if now-self.last_plan_time < .35:
                        return self.stop("waiting_for_observed_bypass")
                    self.last_plan_time = now
                    if not self.select_bypass(vehicle, space):
                        return self.stop("no_verified_bypass")
                    self.completed_hold_seconds = now-self.stopped_since
                    self.phase = "detour"
                    return self.stop("bypass_selected")
                else:
                    return self.stop("waiting_for_stationary_obstacle")

        path = self.route if self.bypass is None else self.bypass.path
        if self.bypass and here.x >= self.bypass.return_start:
            self.phase = "rejoin"
            if here.x >= self.bypass.return_end and abs(here.y) <= .30 and abs(here.yaw) <= .20:
                self.phase = "summit_approach"
        gx, gy = self.route.world(self.route.length)
        if math.hypot(vehicle.x-gx, vehicle.y-gy) <= .44 and abs(here.yaw) <= .20:
            self.phase = "arrived"
            if stationary(vehicle):
                if self.park_since is None:
                    self.park_since = now
                self.done = now-self.park_since >= .75
            else:
                self.park_since = None
            return self.stop("goal_hold")
        self.park_since = None
        return self.checked_motion(now, vehicle, space, path)


class SummitMission:
    def __init__(self, shape, course=SUMMIT, terrain=None):
        self.course = course
        self.navigator = SummitNavigator(shape, course, terrain or summit_terrain(course))

    @property
    def done(self):
        return self.navigator.done

    def fail_closed(self, reason):
        self.navigator.interrupt(reason)
        return Decision(STOP, STOP, None, False, (), reason, None)

    def step(self, now, vehicle, scan):
        command = self.navigator.tick(now, vehicle, scan)
        return Decision(command, STOP, None, False, (), self.navigator.stop_reason or "clear", None)
