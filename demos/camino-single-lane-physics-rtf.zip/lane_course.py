"""Two opposing approaches to one marked section of the Ruskotunturi route."""
import math
from dataclasses import dataclass

from final_sil_v6_checks import polygon_distance
from jarcrac_convoy_v2 import ACKERMANN_CURVATURE
from jarcrac_cooperative_control import CLEARANCE, PAIR_LIMIT, STOP, Motion, angle_error, tracked_command
from jarcrac_cooperative_terrain import LOCAL_FRAME

FRAME = LOCAL_FRAME
SIGNS = (1, -1)
GATE = 11.0
CORE = 2.0
OFFSET = 2.45
START = -17.4
ARRIVAL_LINE = -12.8  # Station of the front of the collision footprint
WAIT = -13.85         # Station of the model origin in its waiting bay
GOAL = 16.9
DELAY = 22.0
SETTLE = 1.5
SPEED = (.25, .30)
TIME_LIMIT = 450.0    # Simulation seconds per crossing pair


def blend(x):
    t = min(1., max(0., (abs(x) - CORE) / (GATE - CORE)))
    return t * t * (3 - 2 * t)


def route_y(i, x):
    return -SIGNS[i] * OFFSET * blend(x)


def point(i, station):
    x = SIGNS[i] * station
    return x, route_y(i, x)


def heading(i):
    return 0. if i == 0 else math.pi


@dataclass(frozen=True)
class Body:
    polygon: tuple
    rear: float
    front: float

    @property
    def in_lane(self):
        return self.front >= -GATE and self.rear <= GATE


def body_at(i, shape, pose):
    polygon = tuple(shape.at(pose))
    stations = [SIGNS[i] * x for x, _ in polygon]
    return Body(polygon, min(stations), max(stations))


def crossing_time(before, after, threshold):
    """Interpolate a forward crossing between two (pose stamp, front station) samples."""
    if before is None or not before[1] < threshold <= after[1]:
        return None
    fraction = (threshold - before[1]) / (after[1] - before[1])
    return before[0] + fraction * (after[0] - before[0])


def follow(i, pose, target):
    remaining = target - SIGNS[i] * pose.x
    if remaining <= .055:
        return STOP
    lookahead = 1.45
    x = pose.x + SIGNS[i] * lookahead
    dx, dy = x - pose.x, route_y(i, x) - pose.y
    error = angle_error(math.atan2(dy, dx), pose.yaw)
    k = 2 * math.sin(error) / math.hypot(dx, dy)
    v = min(SPEED[i], max(.065, .65 * remaining))
    if i == 0:
        return tracked_command(v, max(-.65, min(.65, k)))
    k = max(-ACKERMANN_CURVATURE, min(ACKERMANN_CURVATURE, k))
    return Motion(v, v * k)


class Meeting:
    def __init__(self, shapes, first):
        self.shapes = shapes
        self.delays = tuple(SETTLE + (0. if i == first else DELAY) for i in range(2))
        self.start = None
        self.owner = None
        self.arrived = [None, None]
        self.previous = [None, None]
        self.entered = [False, False]
        self.cleared = [False, False]
        self.fault = None

    def tick(self, now, poses):
        if (self.fault or now is None or any(p is None or not p.fresh(now) for p in poses)
                or abs(poses[0].stamp - poses[1].stamp) > PAIR_LIMIT):
            return STOP, STOP
        if self.start is None:
            self.start = now
        bodies = [body_at(i, self.shapes[i], p) for i, p in enumerate(poses)]
        if any(b.in_lane and i != self.owner for i, b in enumerate(bodies)):
            self.fault = "vehicle footprint entered without holding the lane"
        elif polygon_distance(bodies[0].polygon, bodies[1].polygon) < CLEARANCE:
            self.fault = "vehicle clearance below one metre"
        if self.fault:
            return STOP, STOP

        for i, b in enumerate(bodies):
            sample = (poses[i].stamp, b.front)
            if self.arrived[i] is None:
                self.arrived[i] = crossing_time(self.previous[i], sample, ARRIVAL_LINE)
            self.previous[i] = sample
        if self.owner is not None:
            i = self.owner
            self.entered[i] |= bodies[i].in_lane
            if self.entered[i] and bodies[i].rear > GATE + .22:
                self.cleared[i] = True
                self.owner = None
        if self.owner is None:
            # Resolve on paired measurements. In a true timestamp tie A goes first.
            # Wait for both streams to cover the crossing time before committing.
            watermark = min(p.stamp for p in poses)
            queue = [(t, i) for i, t in enumerate(self.arrived)
                     if t is not None and t <= watermark and not self.cleared[i]]
            if queue:
                self.owner = min(queue)[1]
        commands = []
        for i, pose in enumerate(poses):
            target = GOAL if self.cleared[i] or self.owner == i else WAIT
            command = follow(i, pose, target) if now - self.start >= self.delays[i] else STOP
            commands.append(command)
        return tuple(commands)
