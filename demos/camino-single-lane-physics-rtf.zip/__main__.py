"""Run the single-lane meeting from the checkout, an extracted download, or its ZIP."""
import argparse
import math
from pathlib import Path
import runpy
import sys
import tempfile
import zipfile


def main():
    entry = Path(__file__).resolve()
    roots = (entry.parent, entry.parent.parent.parent)
    scripts = next((root / "edge-path-project/gazebo/scripts" for root in roots
                    if (root / "edge-path-project/gazebo/scripts/jarcrac_cooperative_sil.py").is_file()), None)
    if scripts is None:
        raise SystemExit("Keep the supplied edge-path-project folder beside __main__.py, or run from the checkout.")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(scripts))
    from jarcrac_cooperative_geometry import model_footprints
    from lane_gazebo import drive, native, prepare_portable, watchdog, write_result
    from lane_replay import replay
    from lane_view import write_view

    args = sys.argv[1:]
    if args[:1] == ["_relay"]:
        watchdog(Path(args[1]))
        return 0
    if args[:1] == ["_drive"]:
        return 0 if drive(int(args[1]), Path(args[2]), Path(args[3])) else 1
    parser = argparse.ArgumentParser(description="Two opposing vehicles share a single lane on Ruskotunturi.")
    parser.add_argument("mode", nargs="?", choices=["demo", "replay", "prepare"], default="demo",
                        help="Gazebo window (default), offline kinematic replay, or portable Gazebo world")
    parser.add_argument("--first", choices=["a", "b", "both"], default="both",
                        help="vehicle to launch first; the default runs both arrival orders")
    parser.add_argument("--out", type=Path, help="a new output directory (default: unique temporary directory)")
    parser.add_argument("--headless", action="store_true", help="run Gazebo without its window")
    parser.add_argument("--wall-timeout", type=int, default=1500, metavar="SECONDS",
                        help="wall-clock limit per Gazebo lap (default 1500 seconds)")
    parser.add_argument("--physics-step", type=float, default=0.001, metavar="SECONDS",
                        help="Gazebo max_step_size, e.g. 0.002 (default 0.001)")
    parser.add_argument("--target-rtf", type=float, default=1.0, metavar="FACTOR",
                        help="Gazebo requested real_time_factor, e.g. 1.5 (default 1.0)")
    opts = parser.parse_args(args)
    if opts.wall_timeout < 1:
        parser.error("--wall-timeout must be positive")
    if not math.isfinite(opts.physics_step) or not 0 < opts.physics_step <= .02:
        parser.error("--physics-step must be finite and between 0 and 0.02 seconds")
    if not math.isfinite(opts.target_rtf) or not 0 < opts.target_rtf <= 10:
        parser.error("--target-rtf must be finite and between 0 and 10")
    if opts.out is None:
        out = Path(tempfile.mkdtemp(prefix="camino-single-lane-"))
    else:
        out = opts.out.expanduser().resolve()
        try:
            out.mkdir(parents=True, exist_ok=False)
        except FileExistsError:
            parser.error(f"output already exists: {out}. Choose a new directory.")
    print(f"Output directory: {out}", flush=True)
    if opts.mode == "prepare":
        prepare_portable(out, opts.physics_step, opts.target_rtf)
        print(f"Prepared {out / 'world.sdf'} and its models.")
        return 0
    shapes = model_footprints()
    orders = (0, 1) if opts.first == "both" else ("ab".index(opts.first),)
    completed = []
    for first in orders:
        lap = out / ("first-" + "ab"[first])
        lap.mkdir()
        print(f"{opts.mode} | {'JARCRAC' if first == 0 else 'Vehicle B'} starts first", flush=True)
        if opts.mode == "replay":
            report = replay(first, shapes, lap)
        else:
            report = native(first, shapes, lap, entry, opts.headless, opts.wall_timeout,
                            opts.physics_step, opts.target_rtf)
        write_result(lap, report)
        outcome = "PASS" if report["passed"] else "FAIL"
        print(f"{outcome} | {report['reason']} | {lap / 'result.json'}", flush=True)
        if not report["passed"]:
            return 1
        completed.append((lap, report))
        write_view(out, completed, shapes)
        print(f"  Minimum clearance {report['min_vehicle_clearance_m']:.2f} m; "
              f"stationary wait {report['stationary_wait_s']:.1f} s", flush=True)
    print(f"Open {out / 'watch.html'} to watch the recorded poses.")
    return 0


if __name__ == "__main__":
    archive = Path(sys.argv[0]).resolve()
    try:
        if archive.is_file() and zipfile.is_zipfile(archive):
            # Gazebo and the reference geometry readers require real model paths.
            with tempfile.TemporaryDirectory(prefix="camino-lane-assets-") as workspace:
                with zipfile.ZipFile(archive) as package:
                    for member in package.namelist():
                        if (member.endswith(".py") or member.startswith("edge-path-project/")
                                or member in ("viewer.html.tmpl", "terrain-relief.png")):
                            package.extract(member, workspace)
                sys.path.insert(0, workspace)
                runpy.run_path(str(Path(workspace) / "__main__.py"), run_name="__main__")
        else:
            raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
