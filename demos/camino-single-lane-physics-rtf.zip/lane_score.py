"""Score measured pairs of model poses, independently of decisions and commands."""
import math

from final_sil_v6_checks import polygon_distance
from jarcrac_cooperative_control import CLEARANCE, TILT_LIMIT, angle_error
from lane_course import (
    ARRIVAL_LINE, GATE, GOAL, SIGNS, START, TIME_LIMIT, WAIT, body_at,
    crossing_time, heading, point, route_y,
)

MAX_GAP = .45
GOAL_HOLD = 3.
WAIT_HOLD = 3.


def near(pose, i, station, dx, dy):
    x, y = point(i, station)
    return abs(pose.x - x) <= dx and abs(pose.y - y) <= dy


class Score:
    def __init__(self, shapes, expected_first):
        self.shapes = shapes
        self.expected = expected_first
        self.start = self.last = self.previous = None
        self.fronts = [None, None]
        self.arrivals = [None, None]
        self.entries = [None, None]
        self.exits = [None, None]
        self.goals_since = None
        self.parked_s = self.wait_s = 0.
        self.min_gap = math.inf
        self.max_occupants = self.samples = 0
        self.wait_pose = None
        self.wait_since = None
        self.error = None
        self.passed = False

    @property
    def done(self):
        return bool(self.error or self.passed)

    def observe(self, poses):
        if self.done:
            return
        t = max(p.stamp for p in poses)
        if self.last is not None and t == self.last:
            return
        if any(not all(map(math.isfinite, (p.stamp, p.x, p.y, p.z, p.yaw, p.roll, p.pitch))) for p in poses):
            self.error = "non-finite pose"
            return
        if abs(poses[0].stamp - poses[1].stamp) > .05:
            self.error = "world poses were not time-aligned"
            return
        if self.start is None:
            self.start = t
            if not all(near(p, i, START, .55, .45) and abs(angle_error(heading(i), p.yaw)) < .2
                       for i, p in enumerate(poses)):
                self.error = "first measured poses were outside the starting bays"
                return
        speeds = [math.inf, math.inf]
        turns = [math.inf, math.inf]
        if self.previous is not None:
            for i, (p, old) in enumerate(zip(poses, self.previous)):
                dt = p.stamp - old.stamp
                if not 0. < dt <= MAX_GAP:
                    self.error = "gap or time reversal in measured poses"
                    return
                speeds[i] = math.hypot(p.x - old.x, p.y - old.y) / dt
                turns[i] = abs(angle_error(p.yaw, old.yaw)) / dt
                if speeds[i] > .75 or turns[i] > .60:
                    self.error = "discontinuous or excessive measured motion"
                    return

        self.previous, self.last = poses, t
        self.samples += 1
        if t - self.start > TIME_LIMIT:
            self.error = "simulation deadline exceeded"
            return
        bodies = [body_at(i, self.shapes[i], p) for i, p in enumerate(poses)]
        count = sum(b.in_lane for b in bodies)
        self.max_occupants = max(self.max_occupants, count)
        self.min_gap = min(self.min_gap, polygon_distance(bodies[0].polygon, bodies[1].polygon))
        if count > 1:
            self.error = "both collision footprints occupied the lane"
        elif self.min_gap < CLEARANCE:
            self.error = "vehicle clearance below one metre"
        if self.error:
            return

        for i, (p, b) in enumerate(zip(poses, bodies)):
            if max(abs(p.roll), abs(p.pitch)) > TILT_LIMIT:
                self.error = "vehicle tilt exceeded the route limit"
                return
            if abs(p.y - route_y(i, p.x)) > .72 or not START - .55 <= SIGNS[i] * p.x <= GOAL + .55:
                self.error = "vehicle left its marked approach or route"
                return
            front = (p.stamp, b.front)
            if self.arrivals[i] is None:
                self.arrivals[i] = crossing_time(self.fronts[i], front, ARRIVAL_LINE)
            self.fronts[i] = front
            if b.in_lane:
                if self.exits[i] is not None or self.arrivals[i] is None:
                    self.error = "unexpected lane entry"
                    return
                if self.entries[i] is None:
                    self.entries[i] = t
            elif self.entries[i] is not None and self.exits[i] is None:
                if b.rear <= GATE:
                    self.error = "vehicle backed out of the lane"
                    return
                self.exits[i] = t

        first, other = self.expected, 1 - self.expected
        if all(v is not None for v in self.arrivals):
            if min((when, i) for i, when in enumerate(self.arrivals))[1] != first:
                self.error = "measured arrival order did not match this lap"
                return
        if self.entries[other] is not None and (self.exits[first] is None or self.entries[other] <= self.exits[first]):
            self.error = "second vehicle entered before the first rear cleared"
            return
        # Measure the wait directly, including motion inside the bay before
        # the waiting vehicle could have reached the entry boundary.
        if self.entries[first] is not None and self.exits[first] is None:
            p = poses[other]
            if SIGNS[other] * p.x > WAIT + .32:
                self.error = "waiting vehicle advanced past its bay"
                return
            in_bay = near(p, other, WAIT, .30, .38)
            if self.wait_since is None and in_bay and speeds[other] <= .028 and turns[other] <= .05:
                self.wait_since, self.wait_pose = t, p
            if self.wait_since is not None:
                drift = math.hypot(p.x - self.wait_pose.x, p.y - self.wait_pose.y)
                if not in_bay or drift > .10 or speeds[other] > .065 or turns[other] > .10:
                    self.error = "waiting vehicle moved before the first rear cleared"
                    return
                self.wait_s = t - self.wait_since
            if SIGNS[first] * poses[first].x >= 0. and self.wait_s < WAIT_HOLD:
                self.error = "no sustained stop in the waiting bay by mid-crossing"
                return

        parked = all(v is not None for v in self.exits) and all(
            near(p, i, GOAL, .32, .38) and abs(angle_error(heading(i), p.yaw)) <= .17
            and speeds[i] <= .035 and turns[i] <= .055 for i, p in enumerate(poses))
        if parked:
            if self.goals_since is None:
                self.goals_since = t
            self.parked_s = t - self.goals_since
            self.passed = self.parked_s >= GOAL_HOLD and self.wait_s >= WAIT_HOLD
        else:
            self.goals_since, self.parked_s = None, 0.

    def result(self, source):
        def elapsed(values):
            return {name: round(t - self.start, 3) if t is not None else None
                    for name, t in zip(("A", "B"), values)}

        return {
            "passed": self.passed, "pose_source": source,
            "reason": self.error or ("both parked" if self.passed else "incomplete pose evidence"),
            "expected_first": "AB"[self.expected], "pose_pairs": self.samples,
            "arrival_s": elapsed(self.arrivals), "lane_entry_s": elapsed(self.entries),
            "rear_clear_s": elapsed(self.exits), "max_vehicles_in_lane": self.max_occupants,
            "min_vehicle_clearance_m": round(self.min_gap, 4) if math.isfinite(self.min_gap) else None,
            "waiting_stopped_s": round(self.wait_since - self.start, 3) if self.wait_since is not None else None,
            "stationary_wait_s": round(self.wait_s, 3), "both_parked_s": round(self.parked_s, 3),
            "elapsed_sim_s": round(self.last - self.start, 3) if self.last is not None else None,
        }
