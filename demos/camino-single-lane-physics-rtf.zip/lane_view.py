"""Render a portable offline viewer of scored pose traces."""
import base64
import csv
import json
from pathlib import Path

from jarcrac_cooperative_control import State
from lane_course import ARRIVAL_LINE, CORE, GATE, GOAL, OFFSET, WAIT


def write_view(out, laps, shapes):
    root = Path(__file__).resolve().parent
    traces = []
    for directory, report in laps:
        positions = []
        with (directory / "poses.csv").open(encoding="utf-8", newline="") as stream:
            reader = csv.DictReader(stream)
            for index, row in enumerate(reader):
                frame = [round(float(row[k]), 4) for k in ("sim_s", "a_x", "a_y", "a_yaw", "b_x", "b_y", "b_yaw")]
                if index % 4 == 0:
                    positions.append(frame)
            if positions[-1][0] != frame[0]:
                positions.append(frame)
        traces.append({"report": report, "frames": positions})
    zero = State(0., 0., 0.)
    data = {"laps": traces, "footprints": [s.at(zero) for s in shapes],
            "course": dict(core=CORE, gate=GATE, goal=GOAL, offset=OFFSET, wait=WAIT, arrival=ARRIVAL_LINE)}
    image = base64.b64encode((root / "terrain-relief.png").read_bytes()).decode("ascii")
    html = (root / "viewer.html.tmpl").read_text(encoding="utf-8")
    html = html.replace("@@DATA@@", json.dumps(data, separators=(",", ":"), allow_nan=False)).replace("@@RELIEF@@", image)
    (out / "watch.html").write_text(html, encoding="utf-8")
