"""Closed-loop kinematic replay with track slip, steering lag and terrain attitude."""
import csv
import math

from jarcrac_convoy_v2 import ACKERMANN_CURVATURE
from jarcrac_cooperative_control import State
from jarcrac_cooperative_terrain import terrain_index
from lane_course import FRAME, START, TIME_LIMIT, Meeting, heading, point
from lane_score import Score

TRACE_COLUMNS = ("x", "y", "z", "yaw", "roll", "pitch")


class Trace:
    def __init__(self, stream):
        self.csv = csv.writer(stream)
        self.csv.writerow(["sim_s"] + [f"{v}_{c}" for v in "ab" for c in TRACE_COLUMNS])
        self.origin = None

    def write(self, poses):
        t = max(p.stamp for p in poses)
        if self.origin is None:
            self.origin = t
        self.csv.writerow([round(t - self.origin, 5)] +
                          [round(getattr(p, k), 6) for p in poses for k in TRACE_COLUMNS])


class Chassis:
    def __init__(self, i):
        self.i = i
        self.x, self.y = point(i, START)
        self.yaw = heading(i)
        self.v = self.w = self.vx = self.vy = 0.

    def advance(self, dt, command, traction):
        desired_v = traction * command.speed
        self.v += max(-.8 * dt, min(.6 * dt, (desired_v - self.v) * min(1., dt / .25)))
        turn = command.yaw_rate / command.speed if command.speed > .005 else 0.
        if self.i:
            turn = max(-ACKERMANN_CURVATURE, min(ACKERMANN_CURVATURE, turn))
        else:
            turn *= .88
        self.w += min(1., dt / .26) * (self.v * turn - self.w)
        mid = self.yaw + .5 * self.w * dt
        # The Ackermann model origin is one metre ahead of the rear axle.
        lateral = self.w if self.i else 0.
        self.vx = self.v * math.cos(mid) - lateral * math.sin(mid)
        self.vy = self.v * math.sin(mid) + lateral * math.cos(mid)
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.yaw = math.remainder(self.yaw + self.w * dt, math.tau)

    def pose(self, t, terrain):
        x, y = FRAME.world(self.x, self.y)
        yaw = self.yaw + FRAME.yaw
        c, s = math.cos(yaw), math.sin(yaw)
        def z(dx, dy):
            value = terrain.height_at(x + c * dx - s * dy, y + s * dx + c * dy)
            if value is None:
                raise ValueError("replay wheelbase left the terrain mesh")
            return value
        roll = math.atan2(z(0, .8) - z(0, -.8), 1.6)
        pitch = -math.atan2(z(1, 0) - z(-1, 0), 2.)
        return State(t, self.x, self.y, self.yaw, self.vx, self.vy, self.w, roll, pitch, z(0, 0))


def replay(first, shapes, out, traction=(.96, .99)):
    dt = .1
    terrain = terrain_index(FRAME.origin, 32.)
    vehicles = [Chassis(i) for i in range(2)]
    meeting, score = Meeting(shapes, first), Score(shapes, first)
    with (out / "poses.csv").open("x", newline="", encoding="utf-8") as stream:
        trace = Trace(stream)
        for step in range(math.ceil(TIME_LIMIT / dt) + 2):
            t = step * dt
            poses = tuple(v.pose(t, terrain) for v in vehicles)
            trace.write(poses)
            score.observe(poses)
            if score.done:
                break
            commands = meeting.tick(t, poses)
            if meeting.fault:
                score.error = meeting.fault
                break
            for i, vehicle in enumerate(vehicles):
                vehicle.advance(dt, commands[i], traction[i])
    return score.result("terrain-following kinematic replay")
