"""Regression checks for arrival timing, rear clearance and independent pose evidence."""
import csv
from dataclasses import replace
import math
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
for base in (HERE, HERE.parent.parent):
    scripts = base / "edge-path-project/gazebo/scripts"
    if scripts.is_dir():
        sys.path.insert(0, str(scripts))
        break

from jarcrac_cooperative_control import STOP, State
from jarcrac_cooperative_geometry import GAZEBO, MODELS, model_footprints
from jarcrac_cooperative_sil import NAMES
from lane_course import ARRIVAL_LINE, FRAME, GATE, SIGNS, START, WAIT, Meeting, body_at, heading, point
from lane_gazebo import PoseFeed, prepare
from lane_replay import TRACE_COLUMNS, replay
from lane_score import Score

SHAPES = model_footprints()


def pose(i, t, station):
    return State(t, *point(i, station), heading(i))


def with_front(i, t, front):
    baseline = body_at(i, SHAPES[i], pose(i, t, START)).front - START
    return pose(i, t, front - baseline)


class RightOfWay(unittest.TestCase):
    def test_measured_arrival_overrides_launch_order(self):
        for first in (0, 1):
            driver = Meeting(SHAPES, 1 - first)
            driver.tick(0., tuple(with_front(i, 0., ARRIVAL_LINE - .2) for i in range(2)))
            driver.tick(.1, tuple(with_front(i, .1, ARRIVAL_LINE + (.19 if i == first else .06)) for i in range(2)))
            self.assertEqual(driver.owner, first)

    def test_one_stream_can_arrive_late(self):
        driver = Meeting(SHAPES, 0)
        driver.tick(0., tuple(with_front(i, 0., ARRIVAL_LINE - .1) for i in range(2)))
        driver.tick(.1, (with_front(0, .1, ARRIVAL_LINE + .04), with_front(1, .025, ARRIVAL_LINE - .07)))
        self.assertIsNone(driver.owner)
        driver.tick(.15, (with_front(0, .15, ARRIVAL_LINE + .08), with_front(1, .15, ARRIVAL_LINE + .20)))
        self.assertEqual(driver.owner, 1)

    def test_stale_pose_and_front_exit_do_not_release(self):
        for first in (0, 1):
            driver = Meeting(SHAPES, first)
            driver.tick(0., tuple(with_front(i, 0., ARRIVAL_LINE - .2) for i in range(2)))
            driver.tick(.1, tuple(with_front(i, .1, ARRIVAL_LINE + (.19 if i == first else .06)) for i in range(2)))
            def pair(t, station):
                return tuple(pose(i, t, station if i == first else WAIT) for i in range(2))
            driver.tick(25., pair(25., 0.))
            self.assertTrue(driver.entered[first])
            self.assertEqual(driver.tick(26., pair(25., 0.)), (STOP, STOP))
            self.assertEqual(driver.owner, first)
            bodies = pair(27., GATE + 1.)
            self.assertLess(body_at(first, SHAPES[first], bodies[first]).rear, GATE)
            self.assertEqual(driver.tick(27., bodies)[1-first], STOP)
            self.assertEqual(driver.owner, first)
            driver.tick(28., pair(28., GATE + 2.1))
            self.assertEqual(driver.owner, 1-first)

    def test_simultaneous_requests_break_ties_by_vehicle_id(self):
        driver = Meeting(SHAPES, 1)
        # Explicit equal measurements exercise the queue's tie policy.
        driver.arrived = [3., 3.]
        driver.tick(3., tuple(pose(i, 3., WAIT) for i in range(2)))
        self.assertEqual(driver.owner, 0)

    def test_unauthorized_entry_stops_both(self):
        driver = Meeting(SHAPES, 0)
        commands = driver.tick(1., (pose(0, 1., 0.), pose(1, 1., WAIT)))
        self.assertEqual(commands, (STOP, STOP))
        self.assertIn("without holding", driver.fault)


class PoseEvidence(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with tempfile.TemporaryDirectory() as tmp:
            report = replay(0, SHAPES, Path(tmp))
            if not report["passed"]:
                raise AssertionError(report)
            cls.trace = []
            with (Path(tmp) / "poses.csv").open(encoding="utf-8") as stream:
                for row in csv.DictReader(stream):
                    t = float(row["sim_s"])
                    cls.trace.append(tuple(State(t, **{k: float(row[f"{v}_{k}"]) for k in TRACE_COLUMNS})
                                           for v in "ab"))

    def test_wrong_order(self):
        score = Score(SHAPES, 1)
        for pair in self.trace:
            score.observe(pair)
        self.assertFalse(score.passed)
        self.assertIsNotNone(score.error)

    def test_waiting_vehicle_creeps_before_rear_exit(self):
        score = Score(SHAPES, 0)
        for a, b in self.trace:
            if b.stamp > 60.:
                b = replace(b, x=b.x - .045 * (b.stamp - 60.))
            score.observe((a, b))
            if score.done:
                break
        self.assertIn("moved before", score.error)

    def test_empty_parking_bay_and_missing_samples_cannot_pass(self):
        incomplete, gap = Score(SHAPES, 0), Score(SHAPES, 0)
        for pair in self.trace:
            t = pair[0].stamp
            if t <= 150.:
                incomplete.observe(pair)
            if not 70. < t < 71.:
                gap.observe(pair)
        self.assertFalse(incomplete.result("test")["passed"])
        self.assertIn("gap", gap.error)

    def test_geometry_detects_overlap_and_insufficient_clearance(self):
        for x, separation, reason in ((0., 3., "both collision footprints"), (16., 2.4, "below one metre")):
            score = Score(SHAPES, 0)
            score.start = 0.  # Exercise a single already-running observation.
            score.observe(tuple(State(2., x, i*separation, heading(i)) for i in range(2)))
            self.assertIn(reason, score.error)


class GazeboWorld(unittest.TestCase):
    def test_geometry_and_original_map(self):
        with tempfile.TemporaryDirectory() as scratch:
            sdf = Path(scratch) / "world.sdf"
            prepare(sdf)
            world = ET.parse(sdf).find("world")
            original = ET.parse(GAZEBO / "worlds/ruskotunturi_final_sil_demo_v6_world.sdf").find("world")
            def include(w):
                item = w.find("include[name='ruskotunturi_map']")
                return [(e.tag, e.attrib, e.text.strip()) for e in item]
            self.assertEqual(include(world), include(original))
            for model in world.findall("model"):
                if model.get("name") in NAMES:
                    self.assertIsNotNone(model.find("link/collision"))
                else:
                    self.assertIsNone(model.find(".//collision"))
            for uri in world.findall(".//uri"):
                suffix = uri.text.strip().removeprefix("model://")
                self.assertTrue((MODELS / suffix).exists(), suffix)

    def test_native_pose_feed_uses_world_frame_and_fresh_pairs(self):
        feed = PoseFeed()
        def message(t, indices):
            stamp = SimpleNamespace(sec=int(t), nsec=round((t % 1) * 1e9))
            header = SimpleNamespace(HasField=lambda key: key == "stamp", stamp=stamp)
            items = []
            for i in indices:
                pos = pose(i, t, START)
                x, y = FRAME.world(pos.x, pos.y)
                a = heading(i) + FRAME.yaw
                q = SimpleNamespace(x=0., y=0., z=math.sin(a/2), w=math.cos(a/2))
                items.append(SimpleNamespace(name=NAMES[i], position=SimpleNamespace(x=x, y=y, z=-10.), orientation=q))
            return SimpleNamespace(HasField=lambda key: key == "header", header=header, pose=items)
        feed.receive(message(1., [0]))
        self.assertEqual(feed.drain()[0], [])
        feed.receive(message(1., [1]))
        batch, overflow = feed.drain()
        self.assertFalse(overflow)
        self.assertEqual(len(batch), 1)
        for i, p in enumerate(batch[0]):
            self.assertAlmostEqual(SIGNS[i] * p.x, START)
            self.assertAlmostEqual(p.y, point(i, START)[1])
        feed.receive(message(1.2, [0]))
        self.assertEqual(feed.drain()[0], [])


if __name__ == "__main__":
    unittest.main()
