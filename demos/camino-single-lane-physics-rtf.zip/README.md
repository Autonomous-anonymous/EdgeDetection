# Ruskotunturi single-lane meeting

Tracked JARCRAC and Ackermann Vehicle B approach a forestry road from opposite ends. The first vehicle whose front reaches its amber arrival stripe gets the lane. The second stops in a marked bay and can leave after the first vehicle’s rear clears the opposite gate. Each parks in its own bay. A second lap swaps their launch delays.

## Watch the two crossings

Extract the download and open **watch.html** in a browser. Select **JARCRAC first** or **Vehicle B first**. Playback starts at 8×, so the two four-minute laps take about one minute to watch. The time slider lets you stop at either gate. The included recording comes from the closed-loop kinematic replay.

## Run the live Gazebo demo

On the Linux or WSL machine with Gazebo Harmonic, its Python 3 bindings (`gz.transport13` and `gz.msgs10`), and a working Gazebo window, run the ZIP directly. The archive includes the original terrain, both vehicles, and the required project scripts.

```bash
/usr/bin/python3 ~/Downloads/camino-single-lane.zip demo
```

The default opens one Gazebo window per lap. JARCRAC launches first in lap one. Vehicle B launches first in lap two. For one headless lap with Vehicle B starting first, run

```bash
/usr/bin/python3 ~/Downloads/camino-single-lane.zip demo --first b --headless
```

In an extracted copy, `python3 . demo` works from the directory containing this guide. Use Ctrl+C to stop.

## Reproduce the offline replay

Python 3.10 or newer can rerun the same controller on a kinematic model with track slip, steering lag and terrain-derived roll and pitch.

```bash
python3 ~/Downloads/camino-single-lane.zip replay --out single-lane-run
```

Choose a fresh output directory for every run. The terminal prints its location. Each completed lap produces a time-stamped `poses.csv` and a scored `result.json`. The run directory also contains a new `watch.html` of the successful laps. Live runs record Gazebo world model poses. Replay runs record kinematic poses. Each report identifies its source.

## What earns a pass

- The independently observed front crossings and lane entries match the lap’s intended arrival order. An exact arrival-time tie gives JARCRAC priority.
- At most one collision footprint occupies the 22 m section between the gates. The smallest planar distance between the two projected collision footprints stays at or above 1 m.
- The waiting vehicle has stopped in its bay for at least three seconds by the time the leader reaches the middle. It holds its position until the leader’s trailing footprint clears the exit.
- Both vehicles traverse the marked route and remain stopped in their own parking bays for three seconds, within 450 simulation seconds per lap. Incomplete, discontinuous or missing pose evidence can fail the run.

The live controller uses paired simulated odometry for coordination. Gazebo’s world model poses provide the separate score. The approach stripes and parking bays are visual markings placed in a new world. The terrain model and both terrain meshes are byte-for-byte copies from EdgeDetection revision `61db92a0`. The generated world includes the original map at its original pose.

| Included kinematic recording | Minimum clearance | Stationary wait | Both parked |
| --- | ---: | ---: | ---: |
| JARCRAC first | 2.96 m | 92.7 s | 241.2 s |
| Vehicle B first | 2.95 m | 64.4 s | 240.8 s |

The Gazebo world was generated and its models and resource paths were checked. The packaged measurements above come from the replay. Live Gazebo validation is pending.

## Katso demo

Pura ZIP-tiedosto ja avaa **watch.html** selaimessa. Keltaiset viivat merkitsevät yksikaistaisen osuuden päät. Ensimmäisenä omalle tuloviivalleen saapunut ajoneuvo saa ajovuoron. Toinen odottaa sivutaskussa, kunnes ensimmäisen ajoneuvon takaosa on ylittänyt vastakkaisen päätyviivan. Toisella kierroksella lähtöviiveet vaihtuvat. Vihreä ruutu on JARCRACin pysäköintipaikka ja sininen ruutu ajoneuvon B paikka.

The project model notices accompany the assets under `edge-path-project/gazebo/models/jarcrac/`. [Original EdgeDetection revision](https://github.com/Autonomous-anonymous/EdgeDetection/tree/61db92a0a4bf039891a1b461e82a6b4493d3e20f)

## Configurable Gazebo physics (additional launcher variant)

This package adds optional `--physics-step` and `--target-rtf` arguments to
`demo` and `prepare`. They modify only the generated world SDF's
`physics/max_step_size` and `physics/real_time_factor`; neither the machine
controllers nor the offline replays are changed. Omitting them uses the
original package settings of 0.001 seconds and requested RTF 1.0.

Example, matching the other CAMINO desktop demos:

```bash
python3 ~/camino-single-lane-physics-rtf.zip demo --first a \
  --physics-step 0.002 --target-rtf 1.5 --wall-timeout 1200
```

To inspect the generated world settings without running Gazebo:

```bash
python3 ~/camino-single-lane-physics-rtf.zip prepare --out /tmp/lane-physics-check \
  --physics-step 0.002 --target-rtf 1.5
grep -A3 '<physics ' /tmp/lane-physics-check/world.sdf
```

This launcher variant has not yet received live Gazebo validation. Changing the
physics step can affect numerical behavior and the pass rate. A requested RTF
of 1.5 is a target, not a guaranteed measured simulation speed.
