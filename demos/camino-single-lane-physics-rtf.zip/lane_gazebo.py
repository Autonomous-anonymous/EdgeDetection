"""A separate Gazebo world, odometry controller, and world-pose observation feed."""
from collections import deque
from functools import partial
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import threading
import time
from types import SimpleNamespace
import uuid
import xml.etree.ElementTree as ET

from jarcrac_compact_sil import B_LIDAR, REQUEST_PAIR, reap, relay
from jarcrac_cooperative_control import State
from jarcrac_cooperative_geometry import GAZEBO, MODELS, model_footprints
from jarcrac_cooperative_sil import NAMES, SIM_STATE, Inputs, add, angles, insert_vehicles, stamp_of
from jarcrac_cooperative_terrain import terrain_index
from jarcrac_showcase_scene import outline, paint
from lane_course import (
    ARRIVAL_LINE, FRAME, GATE, GOAL, OFFSET, SIGNS, SPEED, START, WAIT, Meeting, blend, heading, point,
)
from lane_replay import Trace
from lane_score import Score

WORLD = "camino_single_lane"
POSE_TOPIC = f"/world/{WORLD}/pose/info"
SOURCE = "Gazebo world model poses"
ASSETS = ("ruskotunturi_map", "jarcrac", "jarcrac_detailed_tracks", "aeb_vehicle_360_b")


def box(center, length, width):
    x, y = center
    return [(x + sx * length / 2, y + sy * width / 2) for sx, sy in ((-1,-1), (1,-1), (1,1), (-1,1))]


def prepare(path, physics_step=0.001, target_rtf=1.0):
    tree = ET.parse(GAZEBO / "worlds/ruskotunturi_final_sil_demo_v6_world.sdf")
    world = tree.getroot().find("world")
    world.set("name", WORLD)
    physics = world.find("physics")
    if physics is None or physics.find("max_step_size") is None or physics.find("real_time_factor") is None:
        raise ValueError("Gazebo base world has no configurable physics/max_step_size and real_time_factor")
    physics.set("name", f"{physics_step * 1000:g}ms")
    physics.find("max_step_size").text = f"{physics_step:.6f}"
    physics.find("real_time_factor").text = f"{target_rtf:.6f}"
    for name in ("aeb_vehicle_360", "aeb_vehicle_360_b"):
        world.remove(world.find(f"include[name='{name}']"))
    for model in world.findall("model"):
        world.remove(model)
    terrain = terrain_index(FRAME.origin, 34.)
    insert_vehicles(world, terrain, [point(i, START) for i in range(2)],
                    [heading(i) for i in range(2)], FRAME, B_LIDAR)
    edge = []
    for side in (-1, 1):
        for x in range(-20, 20):
            a = (x, side * (1.52 + OFFSET * blend(x)))
            b = (x + 1, side * (1.52 + OFFSET * blend(x + 1)))
            edge.append((a, b, .12))
    paint(world, terrain, FRAME, "road_edges", (.9, .89, .76, 1), edge)
    amber = (1., .69, .14, 1.)
    paint(world, terrain, FRAME, "lane_gates", amber,
          [((x, -3.94), (x, 3.94), .16) for x in (-GATE, GATE)])
    for i, sign in enumerate(SIGNS):
        wait = point(i, WAIT)
        y = wait[1]
        line = sign * ARRIVAL_LINE
        wait_marks = outline(box(wait, 3.55, 2.55), .10)
        wait_marks.append(((line, y - 1.26), (line, y + 1.26), .18))
        paint(world, terrain, FRAME, f"waiting_bay_{i}", amber, wait_marks)
        goal = point(i, GOAL)
        color = ((.30, .90, .64, 1.), (.36, .71, 1., 1.))[i]
        park = outline(box(goal, 3.85, 2.65), .18)
        # A chevron at the far end of the receiving bay indicates the direction of travel.
        for side in (-1, 1):
            park.append(((goal[0] + sign * .9, y + side * .53), (goal[0] + sign * 1.5, y), .12))
        paint(world, terrain, FRAME, f"parking_bay_{i}", color, park)
    gui = add(world, "gui", fullscreen="false")
    view = add(gui, "plugin", filename="MinimalScene", name="3D View")
    props = add(view, "gz-gui")
    add(props, "property", "false", type="bool").set("key", "showTitleBar")
    add(props, "property", "docked", type="string").set("key", "state")
    add(view, "engine", "ogre2")
    add(view, "scene", "scene")
    x, y = FRAME.world(0., -30.)
    z = terrain.height_at(*FRAME.origin) + 34.
    add(view, "camera_pose", f"{x} {y} {z} 0 {math.atan2(34, 30)} {FRAME.yaw + math.pi / 2}")
    for name in ("GzSceneManager", "InteractiveViewControl"):
        plugin = add(gui, "plugin", filename=name, name=name)
        settings = add(plugin, "gz-gui")
        for key, val, kind in (("state", "floating", "string"), ("showTitleBar", "false", "bool"),
                               ("width", "5", "double"), ("height", "5", "double")):
            add(settings, "property", val, type=kind).set("key", key)
    # Keep the terrain include and every asset identical to the source world.
    ET.indent(tree, space="  ")
    with path.open("xb") as stream:
        tree.write(stream, encoding="utf-8", xml_declaration=True)


def prepare_portable(out, physics_step=0.001, target_rtf=1.0):
    prepare(out / "world.sdf", physics_step, target_rtf)
    for model in ASSETS:
        shutil.copytree(MODELS / model, out / "models" / model)


class PoseFeed:
    def __init__(self):
        self.lock = threading.Lock()
        self.latest = [None, None]
        self.used = [-math.inf, -math.inf]
        self.pending = deque()
        self.overflow = False

    def receive(self, message):
        stamp = stamp_of(message)
        if stamp is None:
            return
        updates = {}
        for item in message.pose:
            name = item.name.rsplit("::", 1)[-1]
            if name in NAMES:
                try:
                    roll, pitch, yaw = angles(item.orientation)
                except ValueError:
                    continue
                v = item.position
                updates[NAMES.index(name)] = FRAME.state(State(stamp, v.x, v.y, yaw, roll=roll, pitch=pitch, z=v.z))
        with self.lock:
            for i, pose in updates.items():
                if self.latest[i] is None or self.latest[i].stamp < pose.stamp:
                    self.latest[i] = pose
            if not all(self.latest):
                return
            stamps = [p.stamp for p in self.latest]
            if abs(stamps[0] - stamps[1]) <= .05 and all(t - old >= .08 for t, old in zip(stamps, self.used)):
                if len(self.pending) >= 100:
                    self.overflow = True
                    return
                self.used = stamps
                self.pending.append(tuple(self.latest))

    def drain(self):
        with self.lock:
            pairs = list(self.pending)
            self.pending.clear()
            return pairs, self.overflow


def write_result(out, report):
    (out / "result.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def drive(first, out, ready):
    from gz.msgs10.clock_pb2 import Clock
    from gz.msgs10.double_v_pb2 import Double_V
    from gz.msgs10.odometry_pb2 import Odometry
    from gz.msgs10.pose_v_pb2 import Pose_V
    from gz.transport13 import Node

    node, inputs, feed = Node(), Inputs(FRAME, scan_count=0), PoseFeed()
    pub = node.advertise(REQUEST_PAIR, Double_V)
    subscriptions = [(Clock, f"/world/{WORLD}/clock", inputs.clock_sample), (Pose_V, POSE_TOPIC, feed.receive)]
    subscriptions.extend((Odometry, topic, partial(inputs.vehicle_sample, i)) for i, topic in enumerate(SIM_STATE))
    for kind, topic, callback in subscriptions:
        if not node.subscribe(kind, topic, callback):
            raise RuntimeError(f"Cannot subscribe to {topic}")
    shapes = model_footprints()
    meeting, score = Meeting(shapes, first), Score(shapes, first)
    ending = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: ending.set())
    ready.touch()
    last_evidence = time.monotonic()
    try:
        with (out / "poses.csv").open("x", newline="", encoding="utf-8") as stream:
            trace = Trace(stream)
            while not ending.is_set() and not score.done:
                batches, overflow = feed.drain()
                if overflow:
                    score.error = "world-pose observation queue overflowed"
                    break
                for poses in batches:
                    last_evidence = time.monotonic()
                    trace.write(poses)
                    score.observe(poses)
                    if score.done:
                        break
                now, a, b, _, reset = inputs.snapshot_all()
                if reset:
                    score.error = "simulation clock reset"
                if time.monotonic() - last_evidence > (12. if score.samples else 90.):
                    score.error = "no usable paired observations from " + POSE_TOPIC
                cmd = Double_V()
                values = (0., 0., 0., 0.)
                if score.samples and not score.done:
                    a_cmd, b_cmd = meeting.tick(now, (a, b))
                    values = (a_cmd.speed, a_cmd.yaw_rate, b_cmd.speed, b_cmd.yaw_rate)
                    if meeting.fault:
                        score.error = meeting.fault
                cmd.data.extend(values)
                pub.publish(cmd)
                ending.wait(.035)
    finally:
        cmd = Double_V()
        cmd.data.extend((0., 0., 0., 0.))
        for _ in range(4):
            pub.publish(cmd)
            time.sleep(.04)
        write_result(out, score.result(SOURCE))
    return score.passed


def watchdog(ready):
    relay(ready, SimpleNamespace(a_speed=SPEED[0], b_speed=SPEED[1]), vehicle_indices=(0, 1))


def native(first, shapes, out, entry, headless, wall_timeout, physics_step=0.001, target_rtf=1.0):
    score = Score(shapes, first)
    processes = {}
    env = os.environ.copy()
    env["GZ_PARTITION"] = "camino_lane_" + uuid.uuid4().hex
    env["GZ_SIM_RESOURCE_PATH"] = os.pathsep.join(filter(None, (str(MODELS), env.get("GZ_SIM_RESOURCE_PATH"))))
    def launch(name, command):
        with (out / f"{name}.log").open("xb") as log:
            child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        processes[name] = child
        return child

    failure = None
    deadline = time.monotonic() + wall_timeout
    try:
        gz = shutil.which("gz")
        if not gz:
            raise RuntimeError("Gazebo Harmonic 'gz' is missing. Use the replay command for the offline demo.")
        try:
            __import__("gz.msgs10.odometry_pb2")
            __import__("gz.transport13")
        except ImportError as exc:
            raise RuntimeError("Gazebo Harmonic Python bindings gz.msgs10 and gz.transport13 are required. "
                               "On Ubuntu, launch with /usr/bin/python3.") from exc
        world = out / "world.sdf"
        prepare(world, physics_step, target_rtf)
        print(f"Gazebo physics step {physics_step:.3f} s   Requested RTF {target_rtf:g}", flush=True)
        workers = (("relay", ["_relay"]), ("drive", ["_drive", str(first), str(out)]))
        for name, args in workers:
            ready = out / (name + ".ready")
            child = launch(name, [sys.executable, str(entry), *args, str(ready)])
            until = min(deadline, time.monotonic() + 30.)
            while not ready.exists() and child.poll() is None and time.monotonic() < until:
                time.sleep(.05)
            if not ready.exists():
                raise RuntimeError(f"{name} failed to start. See {name}.log")
        flags = ["-s", "--headless-rendering"] if headless else []
        launch("gazebo", [gz, "sim", "-r", *flags, str(world)])
        while processes["drive"].poll() is None:
            for name in ("gazebo", "relay"):
                code = processes[name].poll()
                if code is not None:
                    raise RuntimeError(f"{name} exited with status {code}. See {name}.log")
            if time.monotonic() >= deadline:
                raise RuntimeError("wall-clock timeout")
            time.sleep(.1)
        if not (out / "result.json").exists():
            raise RuntimeError("controller exited without a score. See drive.log")
    except (OSError, RuntimeError) as exc:
        failure = str(exc)
    finally:
        for name in ("drive", "relay", "gazebo"):
            reap(processes.get(name))
        for name in ("drive", "relay"):
            (out / (name + ".ready")).unlink(missing_ok=True)
    report_path = out / "result.json"
    report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else score.result(SOURCE)
    if failure:
        report.update(passed=False, reason=failure)
    return report
