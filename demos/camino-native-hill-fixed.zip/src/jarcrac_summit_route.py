"""Surveyed world coordinates and distance along the curved summit approach, in metres."""
from bisect import bisect_right
from collections import defaultdict
from dataclasses import replace
from functools import lru_cache
import math

from jarcrac_cooperative_control import angle_error
from jarcrac_cooperative_terrain import RouteFrame, terrain_index
from jarcrac_summit_knots import KNOTS


class Polyline:
    """Arc-length interpolation and nearest-point projection, with tangent extensions."""
    def __init__(self, points):
        self.points = tuple(points)
        self.distances = [0.]
        self.tangents = []
        self.cells = defaultdict(list)
        for i, ((x, y), (u, v)) in enumerate(zip(points, points[1:])):
            length = math.hypot(u-x, v-y)
            self.distances.append(self.distances[-1]+length)
            self.tangents.append(((u-x)/length, (v-y)/length))
            # Any segment intersecting the cell's 5 m surroundings is a candidate.
            for ix in range(math.floor((min(x,u)-5)/3), math.floor((max(x,u)+5)/3)+1):
                for iy in range(math.floor((min(y,v)-5)/3), math.floor((max(y,v)+5)/3)+1):
                    self.cells[ix, iy].append(i)
        self.length = self.distances[-1]
        headings = [math.atan2(ty, tx) for tx, ty in self.tangents]
        self.headings = [headings[0], *(a+.5*angle_error(b, a) for a, b in zip(headings, headings[1:])),
                         headings[-1]]

    def at(self, station):
        i = min(len(self.tangents)-1, max(0, bisect_right(self.distances, station)-1))
        x, y = self.points[i]
        tx, ty = self.tangents[i]
        along = station-self.distances[i]
        fraction = max(0., min(1., along/(self.distances[i+1]-self.distances[i])))
        yaw = self.headings[i]+fraction*angle_error(self.headings[i+1], self.headings[i])
        return x+tx*along, y+ty*along, yaw

    def world(self, station, offset=0.):
        x, y, yaw = self.at(station)
        return x-math.sin(yaw)*offset, y+math.cos(yaw)*offset

    def local(self, x, y):
        best_d2 = math.inf
        indices = self.cells.get((math.floor(x/3), math.floor(y/3)))
        if indices is None:
            indices = range(len(self.tangents))
        for i in indices:
            px, py = self.points[i]
            tx, ty = self.tangents[i]
            dx, dy = x-px, y-py
            along = dx*tx+dy*ty
            if i:
                along = max(0., along)
            if i < len(self.tangents)-1:
                along = min(self.distances[i+1]-self.distances[i], along)
            ex, ey = dx-along*tx, dy-along*ty
            distance2 = ex*ex+ey*ey
            if distance2 < best_d2:
                best_d2 = distance2
                best = self.distances[i]+along, math.copysign(math.sqrt(distance2), tx*dy-ty*dx)
        return best

    def state(self, pose):
        s, d = self.local(pose.x, pose.y)
        _, _, yaw = self.at(s)
        c, n = math.cos(yaw), math.sin(yaw)
        return replace(pose, x=s, y=d, yaw=angle_error(pose.yaw, yaw),
                       vx=c*pose.vx+n*pose.vy, vy=-n*pose.vx+c*pose.vy)


def centerline():
    points = []
    for (s0,x0,y0,a0), (s1,x1,y1,a1) in zip(KNOTS, KNOTS[1:]):
        length = s1-s0
        # Cubic Hermite between surveyed positions with prescribed tangents.
        count = math.ceil(length/.18)
        for i in range(count):
            t = i/count
            w = t*t*(3-2*t)
            u, v = length*t*(1-t)**2, -length*t*t*(1-t)
            points.append(((1-w)*x0+w*x1+u*math.cos(a0)+v*math.cos(a1),
                           (1-w)*y0+w*y1+u*math.sin(a0)+v*math.sin(a1)))
    return Polyline([*points, KNOTS[-1][1:3]])


class SummitCourse:
    # Experimental limits for this simulated hillside, measured in chassis axes.
    pitch_limit = math.radians(24.)
    roll_limit = math.radians(16.)
    ground_pitch_limit = math.radians(23.75)
    ground_roll_limit = math.radians(15.75)
    park_seconds = 3.
    rollback_limit = .30

    def __init__(self):
        self.route = centerline()
        self.climb = Polyline([self.climb_xy(s) for s in self.route.distances])
        self.frame = RouteFrame(KNOTS[0][1:3], KNOTS[0][3])  # rigid launch frame
        self.starts, self.goals = (0., None), (self.route.length, None)
        self.a_speed, self.b_speed, self.sim_timeout = .30, 0., 150.
        self.half_width = 5.8

    def climb_xy(self, station):
        """Skirt the short ridge under the tracks on the upper approach."""
        # Station and offset are in metres on the surveyed arrow. The cosine
        # joins its centerline with zero lateral velocity at both ends.
        fraction = (station-18.45)/2.4
        offset = -.225*(1.+math.cos(math.pi*fraction)) if abs(fraction) < 1. else 0.
        return self.route.world(station, offset)

    def start(self, index):
        return self.starts[index], 0.

    def attitude_ok(self, roll, pitch):
        return abs(roll) <= self.roll_limit and abs(pitch) <= self.pitch_limit

    def fresh_pose(self, pose, now):
        return (pose is not None and pose.fresh(now, self.pitch_limit)
                and self.attitude_ok(pose.roll, pose.pitch))


SUMMIT = SummitCourse()


@lru_cache(maxsize=1)
def summit_terrain(course=SUMMIT):
    return terrain_index(course.route.world(course.route.length/2), 50.)


class GroundProfile:
    """Whole-body ground slopes including half-length and half-width support chords."""
    def __init__(self, shape, terrain):
        self.terrain = terrain
        (x0, x1), (y0, y1), _ = shape.bounds()
        self.dx, self.dy = (x1-x0)/4., (y1-y0)/4.
        self.xs = tuple(x0+i*self.dx for i in range(5))
        self.ys = tuple(y0+i*self.dy for i in range(5))

    def slopes(self, x, y, yaw):
        c, s = math.cos(yaw), math.sin(yaw)
        h = [[self.terrain.height_at(x+c*u-s*v, y+s*u+c*v) for v in self.ys] for u in self.xs]
        if any(z is None for row in h for z in row):
            return None
        along = max(abs(h[i+2][j]-h[i][j]) for i in range(3) for j in range(5))/(2*self.dx)
        across = max(abs(row[j+2]-row[j]) for row in h for j in range(3))/(2*self.dy)
        return math.atan(along), math.atan(across)
