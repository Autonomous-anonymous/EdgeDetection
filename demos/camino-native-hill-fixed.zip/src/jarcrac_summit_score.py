"""Independent pose evaluation for JARCRAC's stump bypass and summit goal."""
from dataclasses import replace
import json
import math
import signal
import threading
import time

from final_sil_v6_checks import polygon_distance
from jarcrac_convoy_score import BypassEvidence
from jarcrac_convoy_v2 import GOAL_POSITION_M, stationary
from jarcrac_cooperative_control import CLEARANCE, HOLD_SECONDS, State, angle_error
from jarcrac_cooperative_sil import NAMES, angles, stamp_of
from jarcrac_summit_route import SUMMIT

WORLD = "camino_jarcrac_native_hill"
STUMP_NAME = "tree_stump"
STUMP_RADIUS = .32
STUMP_HEIGHT = .58
MIN_CLIMB_M = 1.20


def pose_fields(route, vehicle):
    if vehicle is None:
        return dict.fromkeys(("pose_sim_s", "world_x", "world_y", "local_x", "local_y",
                              "route_station_m", "route_offset_m", "local_yaw_deg", "z", "roll_deg", "pitch_deg"))
    here = route.state(vehicle)
    return {"pose_sim_s": vehicle.stamp, "world_x": vehicle.x, "world_y": vehicle.y,
            "local_x": here.x, "local_y": here.y, "route_station_m": here.x, "route_offset_m": here.y,
            "local_yaw_deg": math.degrees(here.yaw), "z": vehicle.z,
            "roll_deg": math.degrees(vehicle.roll), "pitch_deg": math.degrees(vehicle.pitch)}


def stump_outline(x, y):
    # Circumscribe the cylinder for a conservative planar clearance measurement.
    radius = STUMP_RADIUS/math.cos(math.pi/16)
    return tuple((x+radius*math.cos(i*math.tau/16), y+radius*math.sin(i*math.tau/16))
                 for i in range(16))


class Score:
    def __init__(self, shape, course=SUMMIT):
        self.shape, self.course = shape, course
        self.bypass = BypassEvidence()
        self.previous = self.start_z = self.start_time = self.goal_since = None
        self.stump_xy = None
        self.samples = 0
        self.minimum_gap = math.inf
        self.max_roll = self.max_pitch = 0.
        self.furthest_station = -math.inf
        self.max_rollback = self.parked_for = 0.
        self.peak_roll_pose = self.peak_pitch_pose = None
        self.started = self.coverage_gap = self.finished = False

    def record_attitude(self, vehicle):
        if self.peak_roll_pose is None or abs(vehicle.roll) > self.max_roll:
            self.max_roll, self.peak_roll_pose = abs(vehicle.roll), vehicle
        if self.peak_pitch_pose is None or abs(vehicle.pitch) > self.max_pitch:
            self.max_pitch, self.peak_pitch_pose = abs(vehicle.pitch), vehicle

    def observe(self, vehicle, stump):
        self.record_attitude(vehicle)
        dt = vehicle.stamp-self.previous.stamp if self.previous else None
        if dt is not None and dt < .075:
            self.coverage_gap |= dt < 0.
            return
        if dt is None:
            self.start_time, self.start_z = vehicle.stamp, vehicle.z
            here = self.course.frame.state(vehicle)
            self.started = math.dist((here.x, here.y), self.course.start(0)) <= .40 and abs(here.yaw) <= .18
        else:
            self.coverage_gap |= dt > .35
            vehicle = replace(vehicle, vx=(vehicle.x-self.previous.x)/dt, vy=(vehicle.y-self.previous.y)/dt,
                              omega=angle_error(vehicle.yaw, self.previous.yaw)/dt)
        self.previous = vehicle
        self.samples += 1
        route = self.course.route
        if self.stump_xy != (stump.x, stump.y):
            self.stump_xy = stump.x, stump.y
            self.outline = stump_outline(*self.stump_xy)
            stations = [route.local(x,y)[0] for x,y in self.outline]
            self.stump_range = min(stations), max(stations)
        here = route.state(vehicle)
        self.furthest_station = max(self.furthest_station, here.x)
        self.max_rollback = max(self.max_rollback, self.furthest_station-here.x)
        body = self.shape.at(vehicle)
        self.minimum_gap = min(self.minimum_gap, polygon_distance(body, self.outline))
        route_body = [route.local(x, y) for x, y in body]
        self.bypass.observe(here, route_body, *self.stump_range, dt, self.course.a_speed)
        parked = (math.dist((vehicle.x, vehicle.y), route.world(route.length)) <= GOAL_POSITION_M+.12
                  and abs(here.yaw) <= .24 and stationary(vehicle))
        if parked and dt is not None and dt <= .35:
            if self.goal_since is None:
                self.goal_since = vehicle.stamp
            self.parked_for = vehicle.stamp-self.goal_since
            self.finished |= self.parked_for >= self.course.park_seconds
        else:
            self.goal_since = None
            self.parked_for = 0.

    def result(self):
        climb = self.previous.z-self.start_z if self.previous else None
        tilt_violation = not self.course.attitude_ok(self.max_roll, self.max_pitch)
        summit_reached = self.finished and climb is not None and climb >= MIN_CLIMB_M
        duration = self.previous.stamp-self.start_time if self.previous else None
        passed = (duration is not None and duration <= self.course.sim_timeout and self.started and summit_reached and not self.coverage_gap and not tilt_violation
                  and self.minimum_gap >= CLEARANCE and self.bypass.rejoined
                  and self.bypass.hold_s >= HOLD_SECONDS and self.max_rollback <= self.course.rollback_limit)
        goal = self.course.route.world(self.course.route.length)
        return {
            "goal_world_xy_m": goal,
            "final_goal_distance_m": math.dist((self.previous.x,self.previous.y), goal) if self.previous else None,
            "pitch_limit_deg": math.degrees(self.course.pitch_limit),
            "roll_limit_deg": math.degrees(self.course.roll_limit),
            "max_backward_travel_m": self.max_rollback, "rollback_limit_m": self.course.rollback_limit,
            "stationary_at_goal_s": self.parked_for,
            "geometry_passed": bool(passed), "starts_observed": self.started,
            "goals_stopped": self.finished, "summit_reached": summit_reached,
            "pose_samples": self.samples, "coverage_gap": self.coverage_gap,
            "tilt_violation": tilt_violation,
            "duration_sim_s": duration,
            "minimum_obstacle_footprint_gap_m": self.minimum_gap if math.isfinite(self.minimum_gap) else None,
            "a_rejoin_verified": self.bypass.rejoined,
            "a_aligned_progress_m": self.bypass.aligned_m, "a_aligned_progress_s": self.bypass.aligned_s,
            "a_stationary_pose_hold_s": self.bypass.hold_s, "elevation_gain_m": climb,
            "max_abs_roll_deg": math.degrees(self.max_roll), "max_abs_pitch_deg": math.degrees(self.max_pitch),
            "peak_roll_pose": pose_fields(self.course.route, self.peak_roll_pose),
            "peak_pitch_pose": pose_fields(self.course.route, self.peak_pitch_pose),
            "last_scored_pose": pose_fields(self.course.route, self.previous),
        }


def evaluate(shape, report, ready, timeout, *, target_rtf=1.5):
    from gz.msgs10.pose_v_pb2 import Pose_V
    from gz.transport13 import Node

    score, node = Score(shape), Node()
    latest, lock, ending = {}, threading.Lock(), threading.Event()
    watched = NAMES[0], STUMP_NAME
    extrema = {"roll": None, "pitch": None}

    def sample(message):
        stamp = stamp_of(message)
        if stamp is None:
            return
        found = {}
        for pose in message.pose:
            name = pose.name.rsplit("::", 1)[-1]
            if name not in watched:
                continue
            xyz = pose.position.x, pose.position.y, pose.position.z
            if not all(map(math.isfinite, xyz)):
                continue
            try:
                roll, pitch, yaw = angles(pose.orientation)
            except ValueError:
                continue
            found[name] = State(stamp, *xyz[:2], yaw, roll=roll, pitch=pitch, z=xyz[2])
        with lock:
            latest.update(found)
            vehicle = found.get(NAMES[0])
            if vehicle is not None:
                for axis, previous in extrema.items():
                    if previous is None or abs(getattr(vehicle, axis)) > abs(getattr(previous, axis)):
                        extrema[axis] = vehicle

    if not node.subscribe(Pose_V, f"/world/{WORLD}/pose/info", sample):
        raise RuntimeError("Cannot subscribe to summit evaluation poses")
    signal.signal(signal.SIGTERM, lambda *_: ending.set())
    ready.touch()
    deadline = time.monotonic()+timeout
    while not ending.wait(.02/max(1., target_rtf)) and time.monotonic() < deadline:
        with lock:
            vehicle, stump = (latest.get(name) for name in watched)
        if vehicle is None or stump is None:
            continue
        score.observe(vehicle, stump)
        if score.finished:
            break
    with lock:
        for vehicle in extrema.values():
            if vehicle is not None:
                score.record_attitude(vehicle)
    result = score.result()
    report.write_text(json.dumps(result, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    return result["geometry_passed"]
