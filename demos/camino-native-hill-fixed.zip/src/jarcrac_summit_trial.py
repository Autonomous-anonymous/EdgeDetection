#!/usr/bin/env python3
"""Run the isolated JARCRAC summit demo with the CAMINO launcher interface."""
import argparse
from functools import partial
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import uuid
import zipfile
import xml.etree.ElementTree as ET

from jarcrac_compact_sil import REQUEST_PAIR, reap, relay
from jarcrac_convoy_score import hold_evidence
from jarcrac_convoy_v2 import launch_space, stationary
from jarcrac_cooperative_control import AGE_LIMIT, STOP, angle_error
from jarcrac_cooperative_geometry import GAZEBO, MODELS, model_footprints
from jarcrac_cooperative_sil import EXTERNAL_STATE, LIDAR, SIM_STATE, Inputs, insert_vehicles
from jarcrac_cooperative_terrain import WORLD_FRAME, scan_from_message
from jarcrac_summit_mission import SUMMIT, SummitMission, summit_terrain
from jarcrac_summit_scene import DEFAULT_STUMP, summit_scene
from jarcrac_summit_score import WORLD, evaluate, pose_fields


class ClockTiming:
    def __init__(self):
        self.first = self.last = None

    def observe(self, sim_time, wall_time):
        if self.first is None:
            self.first = self.last = sim_time, wall_time
        elif sim_time > self.last[0]:
            self.last = sim_time, wall_time

    @property
    def observed_rtf(self):
        if self.first is None or self.last[1] <= self.first[1]:
            return None
        return round((self.last[0]-self.first[0])/(self.last[1]-self.first[1]), 3)


def prepare(output, obstacle=DEFAULT_STUMP, *, show_lidar=True, physics_step=.002, target_rtf=1.5):
    tree = ET.parse(GAZEBO / "worlds/ruskotunturi_final_sil_demo_v6_world.sdf")
    world = tree.getroot().find("world")
    world.set("name", WORLD)
    world.find("physics/max_step_size").text = str(physics_step)
    world.find("physics/real_time_factor").text = str(target_rtf)
    for name in ("aeb_vehicle_360", "aeb_vehicle_360_b"):
        world.remove(world.find(f"include[name='{name}']"))
    for model in world.findall("model"):
        world.remove(model)
    terrain = summit_terrain()
    insert_vehicles(world, terrain, (SUMMIT.start(0),), (0.,), SUMMIT.frame, vehicle_indices=(0,))
    summit_scene(world, terrain, SUMMIT, obstacle, show_lidar=show_lidar)
    ET.indent(tree, space="  ")
    with output.open("xb") as stream:
        tree.write(stream, encoding="utf-8", xml_declaration=True)


def preview(args):
    gz = shutil.which("gz")
    if gz is None:
        raise RuntimeError("Gazebo Harmonic and the gz command are required for the preview")
    env = dict(os.environ, GZ_PARTITION="camino_native_hill_"+uuid.uuid4().hex)
    env["GZ_SIM_RESOURCE_PATH"] = os.pathsep.join(filter(None, (str(MODELS), env.get("GZ_SIM_RESOURCE_PATH"))))
    with tempfile.TemporaryDirectory(prefix="camino-native-hill-view-") as folder:
        world = Path(folder) / "world.sdf"
        prepare(world, args.obstacle, show_lidar=not args.no_lidar_view,
                physics_step=args.physics_step, target_rtf=args.target_rtf)
        return subprocess.run([gz, "sim", str(world)], env=env).returncode


def stop_reason(decision, now, vehicle, scan, phase):
    if decision.a != STOP:
        return None
    if decision.reason in ("stale_or_excessive_tilt", "waiting_for_start"):
        if now is None:
            return "clock_unavailable"
        if vehicle is None:
            return "pose_unavailable"
        if not -.02 <= now-vehicle.stamp <= AGE_LIMIT:
            return "pose_time_out_of_range"
        if not SUMMIT.attitude_ok(vehicle.roll, vehicle.pitch):
            return "measured_tilt_limit"
        if not SUMMIT.fresh_pose(vehicle, now):
            return "pose_invalid"
        if scan is None:
            return "scan_unavailable"
        return decision.reason
    if decision.reason == "state_or_scan_unavailable":
        return "scan_unavailable" if scan is None else "scan_time_out_of_range"
    return phase if decision.reason == "clear" else decision.reason


def trace_row(now, vehicle, scan, mission, decision):
    nav = mission.navigator
    stopped = stop_reason(decision, now, vehicle, scan, nav.phase)
    checks = list(nav.rejected_checks)
    causes = sorted({check["reason"] for check in checks}) if stopped else []
    return {"sim_s": now, **pose_fields(mission.course.route, vehicle),
            "scan_sim_s": scan.stamp if scan is not None else None, "phase": nav.phase,
            "stop_reason": stopped, "clearance_rejection_reason": ", ".join(causes) or None,
            "rejected_checks": checks, "reason": decision.reason, "b": None,
            "a": {"phase": nav.phase, "hold_s": nav.completed_hold_seconds,
                  "cmd_speed": decision.a.speed, "cmd_yaw_rate": decision.a.yaw_rate,
                  "stop_reason": nav.stop_reason}}


def timeout_reason(now, start_sim, clock_idle_s):
    if now is not None and now-start_sim > SUMMIT.sim_timeout:
        return f"simulation_time_limit ({now-start_sim:.3f} s elapsed, {SUMMIT.sim_timeout:g} s allowed)"
    if clock_idle_s > 8.:
        return f"clock_stalled ({clock_idle_s:.2f} wall seconds without clock progress)"
    return None


def control(source, trace, processes, deadline, timing, *, target_rtf):
    from gz.msgs10.clock_pb2 import Clock
    from gz.msgs10.double_v_pb2 import Double_V
    from gz.msgs10.laserscan_pb2 import LaserScan
    from gz.msgs10.odometry_pb2 import Odometry
    from gz.transport13 import Node

    node, inputs = Node(), Inputs(WORLD_FRAME, 2, SUMMIT.pitch_limit)
    publisher = node.advertise(REQUEST_PAIR, Double_V)
    state_topic = SIM_STATE[0] if source == "gazebo-odometry" else EXTERNAL_STATE[0]
    subscriptions = ((Clock, f"/world/{WORLD}/clock", inputs.clock_sample),
                     (Odometry, state_topic, partial(inputs.vehicle_sample, 0)),
                     (LaserScan, LIDAR, partial(inputs.lidar_sample, index=0)))
    for kind, topic, callback in subscriptions:
        if not node.subscribe(kind, topic, callback):
            raise RuntimeError(f"Cannot subscribe to {topic}")

    def send(command):
        message = Double_V()
        message.data.extend((command.speed, command.yaw_rate, 0., 0.))
        publisher.publish(message)

    terrain = summit_terrain()
    mission = SummitMission(model_footprints()[0], terrain=terrain)
    space = launch_space(SUMMIT)
    seen = scan = start_sim = previous = previous_clock = None
    started = last_clock = time.monotonic()
    interval = .05/max(1., target_rtf)
    try:
        while time.monotonic() < deadline:
            tick = time.monotonic()
            for name, process in processes.items():
                status = process.poll()
                if status is not None and (name != "evaluator" or status != 0):
                    raise RuntimeError(f"{name} exited with status {status}")
            now, vehicle, _, frames, reset = inputs.snapshot_all()
            if reset:
                raise RuntimeError("Gazebo simulation time reset")
            if now is not None and now != previous_clock:
                last_clock, previous_clock = tick, now
                timing.observe(now, tick)
            raw = frames[0]
            if raw is None:
                scan = None
            elif raw[1] != seen:
                message, stamp, pose = raw
                if start_sim is None and not space.launch_clear:
                    space = launch_space(SUMMIT)
                front = (scan_from_message(message, stamp, pose, terrain, WORLD_FRAME)
                         if SUMMIT.attitude_ok(pose.roll, pose.pitch) else None)
                scan = space.update(front, pose) if front else None
                seen = stamp
            elif space.current is not None and space.stamp == raw[1]:
                scan = space
            if (start_sim is None and now is not None and scan is not None and space.launch_clear
                    and SUMMIT.fresh_pose(vehicle, now) and stationary(vehicle)):
                here = SUMMIT.frame.state(vehicle)
                if math.dist((here.x, here.y), SUMMIT.start(0)) > .30 or abs(angle_error(0., here.yaw)) > .16:
                    raise RuntimeError("JARCRAC is outside its fresh start envelope")
                start_sim = now
            expired = None
            if start_sim is None:
                if tick-started > 45.:
                    raise RuntimeError("Missing fresh initial clock, pose or front ranges")
                decision = mission.fail_closed("waiting_for_start")
            else:
                expired = timeout_reason(now, start_sim, tick-last_clock)
                decision = mission.fail_closed(expired) if expired else mission.step(now, vehicle, scan)
            send(decision.a)
            row = trace_row(now, vehicle, scan, mission, decision)
            cause = row["clearance_rejection_reason"]
            status = row["phase"], row["stop_reason"] or decision.reason, cause
            if status != previous:
                location = ""
                if row["local_x"] is not None:
                    location = (f"   route s,d ({row['local_x']:.2f}, {row['local_y']:.2f})"
                                f"   roll {row['roll_deg']:.2f}   pitch {row['pitch_deg']:.2f} deg")
                print(f"sim {now}   summit phase {status[0]}   reason {status[1]}"
                      + location + (f"   clearance {cause}" if cause else ""), flush=True)
                previous = status
            print(json.dumps(row, allow_nan=False), file=trace, flush=True)
            if expired:
                raise RuntimeError(expired)
            if mission.done:
                return
            time.sleep(max(0., interval-(time.monotonic()-tick)))
        raise RuntimeError("wall_time_limit (control wall-clock deadline reached)")
    finally:
        for _ in range(6):
            send(STOP)
            time.sleep(interval)


def demo(args):
    start = time.monotonic()
    deadline = start+args.wall_timeout
    gz = shutil.which("gz")
    if gz is None:
        raise RuntimeError("Gazebo Harmonic and the gz command are required")
    __import__("gz.msgs10.odometry_pb2")
    __import__("gz.transport13")
    out = args.out.resolve()
    out.mkdir(parents=True)
    print(f"Recording summit lap in {out}", flush=True)
    world, trace, report = (out / name for name in ("world.sdf", "control.jsonl", "evaluation.json"))
    prepare(world, args.obstacle, show_lidar=not args.no_lidar_view,
            physics_step=args.physics_step, target_rtf=args.target_rtf)
    os.environ["GZ_PARTITION"] = args.partition or "camino_summit_"+uuid.uuid4().hex
    os.environ["GZ_SIM_RESOURCE_PATH"] = os.pathsep.join(
        filter(None, (str(MODELS), os.environ.get("GZ_SIM_RESOURCE_PATH"))))
    print(f"Gazebo partition {os.environ['GZ_PARTITION']}", flush=True)
    print(f"Physics step {args.physics_step:g} s   Requested RTF {args.target_rtf:g}", flush=True)
    processes, failure, timing = {}, None, ClockTiming()

    def start_worker(name, command):
        with (out / f"{name}.log").open("xb") as log:
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        processes[name] = process
        return process

    try:
        for name in ("relay", "evaluator"):
            ready = out / f".{name}-ready"
            child = start_worker(name, [sys.executable, str(Path(__file__).resolve()), name,
                                        str(ready), str(report), str(max(0., deadline-time.monotonic())),
                                        "--target-rtf", str(args.target_rtf)])
            until = min(deadline, time.monotonic()+15.)
            while not ready.exists() and child.poll() is None and time.monotonic() < until:
                time.sleep(.05)
            if not ready.exists():
                raise RuntimeError(f"{name} failed to start. See {out / (name+'.log')}")
            ready.unlink()
        mode = ["-s", "--headless-rendering"] if args.headless else []
        start_worker("gazebo", [gz, "sim", "-r", *mode, str(world)])
        with trace.open("x", encoding="utf-8") as stream:
            control(args.state_source, stream, processes, deadline-min(5., args.wall_timeout*.1),
                    timing, target_rtf=args.target_rtf)
        processes["evaluator"].wait(timeout=max(0., min(8., deadline-1.-time.monotonic())))
    except (RuntimeError, OSError, ValueError, subprocess.TimeoutExpired, KeyboardInterrupt) as exc:
        failure = str(exc) or type(exc).__name__
    finally:
        for name in ("gazebo", "evaluator", "relay"):
            reap(processes.get(name), grace=max(0., min(4., deadline-time.monotonic())))
    geometry = json.loads(report.read_text()) if report.exists() else {}
    holds = hold_evidence(trace, (0,)) if trace.exists() else {}
    elapsed = time.monotonic()-start
    if elapsed > args.wall_timeout and failure is None:
        failure = "Summit demo exceeded its wall-clock timeout"
    if elapsed > 300. and failure is None:
        failure = "exhibition_wall_time_limit (300 s allowed)"
    passed = failure is None and geometry.get("geometry_passed", False) and bool(holds) and all(holds.values())
    result = {"passed": passed, "failure": failure, "scenario": "summit", "course": "ruskotunturi_native_arrow", "state_source": args.state_source,
              "wall_elapsed_s": round(elapsed, 3), "target_rtf": args.target_rtf,
              "physics_step": args.physics_step, "observed_rtf": timing.observed_rtf, **geometry, **holds}
    if not passed and result["failure"] is None:
        result["failure"] = "independent geometry or controller hold criterion failed"
    (out / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print(f"{'PASS' if passed else 'FAIL'}  {out / 'result.json'}", flush=True)
    if geometry:
        print("Measured summit lap", flush=True)
        for key in ("duration_sim_s", "elevation_gain_m", "minimum_obstacle_footprint_gap_m",
                    "max_abs_pitch_deg", "max_abs_roll_deg", "a_stationary_pose_hold_s",
                    "a_aligned_progress_m", "a_aligned_progress_s", "a_rejoin_verified",
                    "max_backward_travel_m", "stationary_at_goal_s", "final_goal_distance_m", "summit_reached"):
            print(f"  {key} = {geometry.get(key)}")
    archive = out / "summit-reports.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as bundle:
        for name in ("result.json", "evaluation.json", "control.jsonl", "evaluator.log", "relay.log"):
            if (out / name).is_file():
                bundle.write(out / name, name)
    print(f"Reports to attach: {archive}", flush=True)
    return passed


def play_loop(args):
    root = args.out.resolve()
    root.mkdir(parents=True)
    lap = 1
    while args.laps is None or lap <= args.laps:
        destination = root / f"lap-{lap:03d}"
        command = [sys.executable, str(Path(__file__).resolve()), "demo", "--scenario", "summit",
                   "--out", str(destination), "--wall-timeout", str(args.wall_timeout),
                   "--physics-step", str(args.physics_step), "--target-rtf", str(args.target_rtf)]
        for flag, enabled in (("--headless", args.headless), ("--no-lidar-view", args.no_lidar_view)):
            if enabled:
                command.append(flag)
        child = subprocess.Popen(command, start_new_session=True)
        try:
            status = child.wait()
        except KeyboardInterrupt:
            if child.poll() is None:
                child.send_signal(signal.SIGINT)
            child.wait()
            return 130
        if status:
            print(f"Summit loop stopped at lap {lap}. See {destination}", file=sys.stderr)
            return status
        lap += 1
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    setup = sub.add_parser("prepare")
    view = sub.add_parser("preview", help="Open the native route paused in Gazebo")
    setup.add_argument("world", type=Path)
    run = sub.add_parser("demo")
    loop = sub.add_parser("loop")
    loop.add_argument("--laps", type=int)
    run.add_argument("--partition")
    run.add_argument("--state-source", choices=("gazebo-odometry", "external"), default="gazebo-odometry")
    for command in (setup, view, run, loop):
        command.add_argument("--scenario", choices=("summit",), default="summit")
        command.add_argument("--no-lidar-view", action="store_true")
        command.add_argument("--physics-step", type=float, default=.002)
        command.add_argument("--target-rtf", type=float, default=1.5)
    for command in (run, loop):
        command.add_argument("--out", type=Path, required=True)
        command.add_argument("--headless", action="store_true")
        command.add_argument("--wall-timeout", type=float, default=300.)
    for command in (setup, view, run):
        command.add_argument("--obstacle", nargs=2, type=float, default=DEFAULT_STUMP, metavar=("STATION_M", "OFFSET_M"))
    for name in ("relay", "evaluator"):
        worker = sub.add_parser(name)
        worker.add_argument("ready", type=Path)
        worker.add_argument("report", type=Path)
        worker.add_argument("timeout", type=float)
        worker.add_argument("--target-rtf", type=float, default=1.5)
    args = parser.parse_args()
    if not math.isfinite(args.target_rtf) or not .1 <= args.target_rtf <= 5.:
        parser.error("Requested RTF must be between 0.1 and 5.0")
    if args.action in ("prepare", "preview", "demo", "loop"):
        if not math.isfinite(args.physics_step) or not .0005 <= args.physics_step <= .002:
            parser.error("Physics step must be between 0.0005 and 0.002 seconds")
    if args.action in ("demo", "loop"):
        if not math.isfinite(args.wall_timeout) or args.wall_timeout <= 0.:
            parser.error("Wall timeout must be positive and finite")
    if args.action in ("prepare", "preview", "demo") and not all(map(math.isfinite, args.obstacle)):
        parser.error("Obstacle coordinates must be finite")
    if args.action == "loop" and args.laps is not None and args.laps <= 0:
        parser.error("The lap count must be positive")
    try:
        if args.action == "prepare":
            prepare(args.world, args.obstacle, show_lidar=not args.no_lidar_view,
                    physics_step=args.physics_step, target_rtf=args.target_rtf)
            print(args.world)
        elif args.action == "preview":
            return preview(args)
        elif args.action == "relay":
            relay(args.ready, SUMMIT, vehicle_indices=(0,))
        elif args.action == "evaluator":
            return 0 if evaluate(model_footprints()[0], args.report, args.ready, args.timeout,
                                 target_rtf=args.target_rtf) else 1
        elif args.action == "loop":
            return play_loop(args)
        else:
            return 0 if demo(args) else 1
    except (RuntimeError, OSError, ValueError, ImportError) as exc:
        parser.exit(1, str(exc)+"\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
