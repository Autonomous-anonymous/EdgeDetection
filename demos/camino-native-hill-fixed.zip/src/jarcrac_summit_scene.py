"""A stump, terrain-following markings and the solo summit camera."""
import math

from final_sil_v6_checks import polygon_distance
from jarcrac_cooperative_sil import add
from jarcrac_cooperative_terrain import WORLD_FRAME
from jarcrac_showcase_scene import outline, paint
from jarcrac_summit_score import STUMP_HEIGHT, STUMP_NAME, STUMP_RADIUS, stump_outline

DEFAULT_STUMP = (10.8, -.65)


def follow_ground(model, terrain):
    """Tilt each short visual mark to the natural ground along its own tangent."""
    for strip in model.findall("link/visual"):
        pose = strip.find("pose")
        x, y, _, _, _, yaw = map(float, pose.text.split())
        size = strip.find("geometry/box/size")
        length, width, depth = map(float, size.text.split())
        dx, dy = .5*length*math.cos(yaw), .5*length*math.sin(yaw)
        low = terrain.height_at(x-dx, y-dy)
        high = terrain.height_at(x+dx, y+dy)
        pitch = -math.atan2(high-low, length)
        pose.text = f"{x} {y} {(low+high)/2+.036} 0 {pitch} {yaw}"
        size.text = f"{math.hypot(length, high-low)} {width} {depth}"


def place_stump(world, terrain, course, obstacle):
    wx, wy = course.route.world(*obstacle)
    launch = [course.frame.world(u,v) for u,v in ((-3.1,-3.), (3.1,-3.), (3.1,3.), (-3.1,3.))]
    footprint = stump_outline(wx, wy)
    if polygon_distance(footprint, launch) <= 1e-6:
        raise ValueError("Stump meets the clear start envelope")
    heights = [terrain.height_at(u, v) for u,v in (*footprint, (wx,wy))]
    if any(z is None for z in heights):
        raise ValueError("Stump is outside the mapped terrain")
    base = min(heights)-.015
    model = add(world, "model", name=STUMP_NAME)
    add(model, "static", "true")
    add(model, "pose", f"{wx} {wy} {base+STUMP_HEIGHT/2} 0 0 0")
    link = add(model, "link", name="wood")
    for role in ("collision", "visual"):
        body = add(link, role, name="stump")
        cylinder = add(add(body, "geometry"), "cylinder")
        add(cylinder, "radius", STUMP_RADIUS)
        add(cylinder, "length", STUMP_HEIGHT)
        if role == "visual":
            material = add(body, "material")
            add(material, "ambient", ".34 .18 .09 1")
            add(material, "diffuse", ".34 .18 .09 1")
    cap = add(link, "visual", name="cut_face")
    add(cap, "pose", f"0 0 {STUMP_HEIGHT/2-.006} 0 0 0")
    cylinder = add(add(cap, "geometry"), "cylinder")
    add(cylinder, "radius", STUMP_RADIUS-.022)
    add(cylinder, "length", .014)
    material = add(cap, "material")
    add(material, "ambient", ".78 .60 .38 1")
    add(material, "diffuse", ".78 .60 .38 1")


def summit_scene(world, terrain, course, obstacle, *, show_lidar):
    place_stump(world, terrain, course, obstacle)
    route = course.route
    gx, gy = route.world(route.length)
    ring = tuple((gx+1.55*math.cos(i*math.tau/16), gy+1.55*math.sin(i*math.tau/16)) for i in range(16))
    paint(world, terrain, WORLD_FRAME, "summit_goal_marker", (.26,.86,.52,1.), outline(ring,.21))
    stripes = [(route.world(s), route.world(s+.65), .10) for s in range(0, int(route.length)-2, 2)]
    paint(world, terrain, WORLD_FRAME, "uphill_route_markers", (.84,.14,.09,1.), stripes)
    for name in ("summit_goal_marker", "uphill_route_markers"):
        follow_ground(world.find(f"model[@name='{name}']"), terrain)
    world.find("scene/shadows").text = "false"
    previous = world.find("gui")
    if previous is not None:
        world.remove(previous)
    gui = add(world, "gui", fullscreen="false")
    view = add(gui, "plugin", filename="MinimalScene", name="3D View")
    props = add(view, "gz-gui")
    add(props, "property", "false", type="bool").set("key", "showTitleBar")
    add(props, "property", "docked", type="string").set("key", "state")
    add(view, "engine", "ogre2")
    add(view, "scene", "scene")
    mx, my, _ = route.at(route.length/2)
    cam_yaw = math.radians(-91.)
    x, y = mx-26*math.cos(cam_yaw), my-26*math.sin(cam_yaw)
    z = terrain.height_at(mx,my)+19.
    add(view, "camera_pose", f"{x} {y} {z} 0 {math.atan2(19.,26.)} {cam_yaw}")
    for name, title in (("GzSceneManager", "Scene Manager"), ("InteractiveViewControl", "Interactive View Control")):
        plugin = add(gui, "plugin", filename=name, name=title)
        settings = add(plugin, "gz-gui")
        for key, value, kind in (("resizable", "false", "bool"), ("width", "5", "double"),
                                 ("height", "5", "double"), ("state", "floating", "string"),
                                 ("showTitleBar", "false", "bool")):
            add(settings, "property", value, type=kind).set("key", key)
    stats = add(gui, "plugin", filename="WorldStats", name="World stats")
    settings = add(stats, "gz-gui")
    for key, value, kind in (("showTitleBar", "false", "bool"), ("state", "floating", "string"),
                             ("width", "290", "double"), ("height", "110", "double"), ("z", "1", "double")):
        add(settings, "property", value, type=kind).set("key", key)
    anchors = add(settings, "anchors", target="3D View")
    add(anchors, "line", own="right", target="right")
    add(anchors, "line", own="bottom", target="bottom")
    for field in ("sim_time", "real_time", "real_time_factor", "iterations"):
        add(stats, field, "true")
    add(stats, "topic", f"/world/{world.get('name')}/stats")
    if show_lidar:
        add(gui, "plugin", filename="VisualizeLidar", name="Visualize Lidar")
