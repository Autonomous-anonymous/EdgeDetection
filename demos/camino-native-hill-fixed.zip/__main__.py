"""Run the photographed hillside course from a Camino checkout."""
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import zipfile


def main():
    args = sys.argv[1:]
    if args in (["-h"], ["--help"]):
        archive_name = shlex.quote(Path(sys.argv[0]).name)
        print("Run from the Camino summit checkout.\n"
              f"  python3 {archive_name} [demo] [--out DIRECTORY] [--headless]\n"
              f"  python3 {archive_name} preview\n"
              f"  python3 {archive_name} loop [--laps N] [--out DIRECTORY]\n"
              f"  python3 {archive_name} prepare WORLD.sdf\n"
              f"  python3 {archive_name} replay [--track-contact] [--obstacle STATION_M OFFSET_M]\n"
              "Use 'demo --help' for all lap options. A fresh output directory is created by default.")
        return 0
    if not args or args[0].startswith("-"):
        args = ["demo", *args]
    source = Path.cwd() / "edge-path-project/gazebo/scripts"
    requires = ("jarcrac_compact_sil.py", "jarcrac_convoy_score.py", "jarcrac_showcase_scene.py")
    if not all((source / name).is_file() for name in requires):
        print("Run from your Camino checkout, for example ~/camino-summit-test.", file=sys.stderr)
        return 2
    if args[0] in ("demo", "loop") and not any(
            opt == "--out" or opt.startswith("--out=") for opt in args) and not {"-h","--help"}.intersection(args):
        root = Path(tempfile.mkdtemp(prefix="camino-native-hill-"))
        args.extend(["--out", str(root / ("lap" if args[0] == "demo" else "laps"))])
    with tempfile.TemporaryDirectory(prefix="camino-summit-code-") as folder:
        code = Path(folder)
        with zipfile.ZipFile(Path(sys.argv[0]).resolve()) as archive:
            for name in archive.namelist():
                entry = Path(name)
                if entry.parent.as_posix() == "src" and entry.suffix == ".py":
                    (code / entry.name).write_bytes(archive.read(name))
            script = "jarcrac_summit_trial.py"
            if args[0] == "replay":
                script = "replay_summit.py"
                for helper in (script, "track_contact_replay.py"):
                    (code / helper).write_bytes(archive.read("tests/"+helper))
                args = args[1:]
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        env["PYTHONPATH"] = os.pathsep.join(filter(None, (str(code), str(source), env.get("PYTHONPATH"))))
        try:
            return subprocess.run([sys.executable, "-u", str(code / script), *args],
                                  env=env).returncode
        except KeyboardInterrupt:
            return 130


if __name__ == "__main__":
    raise SystemExit(main())
