"""Rigid-body tilt replay with prescribed planar motion on the native collision meshes."""
import math
import xml.etree.ElementTree as ET

import dartpy as dart

from jarcrac_cooperative_control import State
from jarcrac_cooperative_geometry import MODELS, MODEL_NAMES


def origin(parent, pose):
    values = pose.split()
    ET.SubElement(parent, "origin", xyz=" ".join(values[:3]), rpy=" ".join(values[3:]))


def mesh(geometry, uri):
    path = MODELS / uri.removeprefix("model://")
    ET.SubElement(geometry, "mesh", filename=path.as_uri())


def joint(model, name, parent, child, kind):
    element = ET.SubElement(model, "joint", name=name, type=kind)
    ET.SubElement(element, "parent", link=parent)
    ET.SubElement(element, "child", link=child)
    return element


def contact_vehicle():
    """Keep the fixed model links, collision poses, mass distribution and inertias."""
    model = ET.Element("robot", name="summit_contact_vehicle")
    ET.SubElement(model, "link", name="anchor")
    parent = "anchor"
    # The first three axes follow the drive commands. Gravity and contacts
    # determine vertical travel, pitch and roll, in that rotation order.
    axes = (("x", "prismatic", "1 0 0"), ("y", "prismatic", "0 1 0"),
            ("yaw", "continuous", "0 0 1"), ("z", "prismatic", "0 0 1"),
            ("pitch", "continuous", "0 1 0"), ("roll", "continuous", "1 0 0"))
    for name, kind, direction in axes:
        child = name + "_link"
        carrier = ET.SubElement(model, "link", name=child)
        inertia = ET.SubElement(carrier, "inertial")
        ET.SubElement(inertia, "mass", value="0.000001")
        ET.SubElement(inertia, "inertia", ixx="1e-6", iyy="1e-6", izz="1e-6",
                      ixy="0", ixz="0", iyz="0")
        axis = joint(model, name, parent, child, kind)
        ET.SubElement(axis, "axis", xyz=direction)
        if kind == "prismatic":
            ET.SubElement(axis, "limit", lower="-200", upper="200", effort="1e7", velocity="30")
        parent = child

    source = ET.parse(MODELS / MODEL_NAMES[0] / "model.sdf")
    for body in source.findall("model/link"):
        name = body.get("name")
        link = ET.SubElement(model, "link", name=name)
        origin(joint(model, name + "_fixed", parent, name, "fixed"), body.findtext("pose"))
        inertial = ET.SubElement(link, "inertial")
        origin(inertial, body.findtext("inertial/pose"))
        ET.SubElement(inertial, "mass", value=body.findtext("inertial/mass"))
        tensor = {entry.tag: entry.text for entry in body.find("inertial/inertia")}
        ET.SubElement(inertial, "inertia", tensor)
        for source_collision in body.findall("collision"):
            collision = ET.SubElement(link, "collision", name=source_collision.get("name"))
            origin(collision, source_collision.findtext("pose", "0 0 0 0 0 0"))
            geometry = ET.SubElement(collision, "geometry")
            size = source_collision.findtext("geometry/box/size")
            if size is not None:
                ET.SubElement(geometry, "box", size=size)
            else:
                mesh(geometry, source_collision.findtext("geometry/mesh/uri"))
    return model


class TrackContactReplay:
    step = .002

    def __init__(self, pose, record_attitude=None):
        self.record_attitude = record_attitude
        loader = dart.utils.DartLoader()
        loader.setOptions(dart.utils.DartLoaderOptions(defaultRootJointType=dart.utils.DartLoaderRootJointType.FIXED))
        terrain = ET.Element("robot", name="hill")
        link = ET.SubElement(terrain, "link", name="ground")
        geometry = ET.SubElement(ET.SubElement(link, "collision"), "geometry")
        native = ET.parse(MODELS / "ruskotunturi_map/model.sdf")
        mesh(geometry, native.findtext("model/link/collision/geometry/mesh/uri"))

        self.world = dart.simulation.World()
        self.world.setGravity([0., 0., -9.80665])
        self.world.setTimeStep(self.step)
        self.world.getConstraintSolver().setCollisionDetector(dart.collision.FCLCollisionDetector())
        ground, self.vehicle = (loader.parseSkeletonString(ET.tostring(model, encoding="unicode"), MODELS.as_uri())
                                for model in (terrain, contact_vehicle()))
        for skeleton in (ground, self.vehicle):
            self.world.addSkeleton(skeleton)
            # The planar drive is prescribed. Only the normal contact force
            # is needed here to predict the chassis attitude.
            for body in skeleton.getBodyNodes():
                for shape in body.getShapeNodes():
                    if shape.hasDynamicsAspect():
                        shape.getDynamicsAspect().setFrictionCoeff(0.)
        self.vehicle.setPositions([pose.x, pose.y, pose.yaw, pose.z, pose.pitch, pose.roll])
        self.drive_axes = [self.vehicle.getJoint(name) for name in ("x", "y", "yaw")]
        for axis in self.drive_axes:
            axis.setActuatorType(dart.dynamics.ActuatorType.VELOCITY)

    def advance(self, pose, speed, omega, dt):
        substeps = round(dt / self.step)
        if substeps < 1 or not math.isclose(substeps * self.step, dt):
            raise ValueError("Replay interval must contain whole contact steps")
        heading = pose.yaw + .5*dt*omega
        vx, vy = speed*math.cos(heading), speed*math.sin(heading)
        for axis, value in zip(self.drive_axes, (vx, vy, omega)):
            axis.setCommand(0, value)
        for i in range(1, substeps+1):
            self.world.step(False)
            x, y, yaw, z, pitch, roll = self.vehicle.getPositions().tolist()
            state = State(pose.stamp+i*self.step, x, y, yaw, vx, vy, omega,
                          roll=roll, pitch=pitch, z=z)
            if self.record_attitude is not None:
                self.record_attitude(state)
        return state
