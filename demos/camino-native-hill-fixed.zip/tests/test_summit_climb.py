"""Regression checks for measured tilt, the rear blind spot and the curved route."""
from dataclasses import replace
from importlib.util import find_spec
import math
import unittest
from pathlib import Path
import tempfile
import xml.etree.ElementTree as ET

from jarcrac_convoy_v2 import launch_space
from jarcrac_cooperative_control import State, STOP, angle_error
from jarcrac_cooperative_geometry import GAZEBO, model_footprints
from jarcrac_cooperative_terrain import FrontScan, WORLD_FRAME, spawn_pose
from jarcrac_summit_mission import SUMMIT, SummitMission, summit_terrain
from jarcrac_summit_score import Score
from jarcrac_summit_scene import DEFAULT_STUMP
from jarcrac_summit_trial import prepare, timeout_reason


def view(stamp, pose, along, obstruction=math.inf):
    return FrontScan(stamp, pose.x+along*math.cos(pose.yaw), pose.y+along*math.sin(pose.yaw),
                     pose.yaw, (10.,)*181, (obstruction,)*181)


class SummitChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.shape = model_footprints()[0]
        cls.terrain = summit_terrain()

    def setUp(self):
        self.mission = SummitMission(self.shape, terrain=self.terrain)
        self.pose = State(2., *SUMMIT.route.at(12.))
        self.space = launch_space(SUMMIT)

    def test_padded_rear_requires_positive_observation(self):
        pose, space = self.pose, self.space
        space.update(view(2., pose, 1.68), pose)
        nav = self.mission.navigator
        self.assertFalse(nav.clear_at(space, pose.x, pose.y, pose.yaw))
        reason = nav.rejected_checks[-1]
        self.assertEqual(reason["reason"], "lidar_unobserved")
        self.assertLess(reason["body_xy"][0], -2.4)
        self.assertLess(reason["body_xy"][1], -1.8)
        nav.phase = "follow"
        self.assertEqual(self.mission.step(2., pose, space).a, STOP)
        self.assertEqual(nav.stop_reason, "stopping_space_unverified")

    def test_recent_positive_view_and_new_obstruction(self):
        pose, space = self.pose, self.space
        space.update(view(1.9, pose, -6.), pose)
        space.update(view(2., pose, 1.68), pose)
        nav = self.mission.navigator
        self.assertTrue(nav.clear_at(space, pose.x, pose.y, pose.yaw))
        space.update(view(2.1, pose, -6., obstruction=1.), pose)
        self.assertFalse(nav.clear_at(space, pose.x, pose.y, pose.yaw))
        self.assertEqual(nav.rejected_checks[-1]["reason"], "lidar_obstruction")

    def test_measured_pitch_and_stale_scan_stop_motion(self):
        self.mission.navigator.phase = "follow"
        self.space.update(view(2., self.pose, -6.), self.pose)
        for unsafe in (replace(self.pose, pitch=-SUMMIT.pitch_limit-.001),
                       replace(self.pose, roll=SUMMIT.roll_limit+.001)):
            self.assertEqual(self.mission.step(2., unsafe, self.space).a, STOP)
        self.assertTrue(SUMMIT.fresh_pose(replace(self.pose,pitch=math.radians(-18)), 2.))
        self.assertEqual(self.mission.step(2.35, replace(self.pose, stamp=2.35), self.space).a, STOP)
        self.assertEqual(self.mission.navigator.stop_reason, "state_or_scan_unavailable")

    def test_peak_on_an_intermediate_pose_counts(self):
        score = Score(self.shape)
        start = State(1., *SUMMIT.route.at(0.), z=28.)
        stump = State(1., *SUMMIT.route.world(10.5, -.12))
        score.observe(start, stump)
        peak = SUMMIT.pitch_limit+math.radians(.2)
        score.observe(replace(start, stamp=1.04, pitch=-peak), stump)
        score.observe(replace(start, stamp=1.10), stump)
        result = score.result()
        self.assertTrue(result["tilt_violation"])
        self.assertFalse(result["geometry_passed"])
        self.assertAlmostEqual(result["max_abs_pitch_deg"], math.degrees(peak))

    def test_stump_bypass_joins_the_upper_guide_and_finishes_on_the_arrow(self):
        route = SUMMIT.route
        pose = State(1., *route.at(1.64))
        bypass = next(self.mission.navigator.bypass_candidates(pose, 10.51, -.60, 1.))
        for path in (SUMMIT.climb, bypass.path):
            # Both navigation paths skirt the ridge at station 18.45. The
            # surveyed line still defines the markers, the goal and the score.
            ridge = route.world(18.45)
            station, _ = path.local(*ridge)
            _, lateral = route.local(*path.world(station))
            self.assertLess(lateral, -.35)
            self.assertLess(math.dist(path.points[-1], route.points[-1]), 1e-8)
            self.assertLess(abs(angle_error(path.at(path.length)[2], route.at(route.length)[2])), .02)

    @unittest.skipUnless(find_spec("dartpy"), "track-contact replay requires dartpy")
    def test_track_contacts_reproduce_the_crest_failure_and_clear_the_new_approach(self):
        from track_contact_replay import TrackContactReplay

        def peak_pitch(path):
            station, dt, step_m = 16., .05, .01
            x, y, yaw = path.at(station)
            x, y, z, roll, pitch, yaw = spawn_pose(self.terrain, self.shape, (x, y), yaw, WORLD_FRAME)
            pose = State(0., x, y, yaw, roll=roll, pitch=pitch, z=z)
            score = Score(self.shape)
            contacts = TrackContactReplay(pose, score.record_attitude)
            for _ in range(30):
                pose = contacts.advance(pose, 0., 0., dt)
            for _ in range(360):
                station += step_m
                x, y, yaw = path.at(station)
                speed = math.hypot(x-pose.x, y-pose.y)/dt
                omega = angle_error(yaw, pose.yaw)/dt
                pose = contacts.advance(pose, speed, omega, dt)
            return score.max_pitch

        self.assertGreater(peak_pitch(SUMMIT.route), SUMMIT.pitch_limit)
        self.assertLess(peak_pitch(SUMMIT.climb), SUMMIT.pitch_limit-math.radians(2.))

    def test_lateral_limit_and_rollback_are_reported_separately(self):
        score = Score(self.shape)
        stump = State(1., *SUMMIT.route.world(*DEFAULT_STUMP))
        for stamp,station in ((1.,0.),(2.,1.),(2.2,.6)):
            x,y,yaw = SUMMIT.route.at(station)
            score.observe(State(stamp,x,y,yaw,roll=SUMMIT.roll_limit+.001), stump)
        record = score.result()
        self.assertTrue(record["tilt_violation"])
        self.assertAlmostEqual(record["max_backward_travel_m"], .4)
        self.assertGreater(record["max_backward_travel_m"], record["rollback_limit_m"])

    def test_padded_box_encloses_full_collision_model_at_permitted_tilts(self):
        nav = self.mission.navigator
        (xmin,xmax),(ymin,ymax) = nav.padded_bounds
        for i in range(-5,6):
            for j in range(-5,6):
                (x0,x1),(y0,y1),_ = self.shape.bounds(i*SUMMIT.roll_limit/5, j*SUMMIT.pitch_limit/5)
                self.assertLessEqual(xmin, x0-nav.padding+1e-9)
                self.assertGreaterEqual(xmax, x1+nav.padding-1e-9)
                self.assertLessEqual(ymin, y0-nav.padding+1e-9)
                self.assertGreaterEqual(ymax, y1+nav.padding-1e-9)

    def test_only_native_ground_and_photographed_ascent(self):
        template = ET.parse(GAZEBO/"worlds/ruskotunturi_final_sil_demo_v6_world.sdf").find("world")
        with tempfile.TemporaryDirectory() as folder:
            out = Path(folder)/"hill.sdf"
            prepare(out)
            world = ET.parse(out).find("world")
            self.assertEqual(list(out.parent.iterdir()), [out])
            self.assertEqual([obj.findtext("uri") for obj in world.findall("include")],
                             ["model://ruskotunturi_map"])
            terrain = world.find("include[name='ruskotunturi_map']")
            self.assertEqual(ET.canonicalize(ET.tostring(terrain), strip_text=True),
                             ET.canonicalize(ET.tostring(template.find("include[name='ruskotunturi_map']")), strip_text=True))
            solids = {m.get("name") for m in world.findall("model") if m.find(".//collision") is not None}
            self.assertEqual(solids, {"camino_jarcrac","tree_stump"})
            xy = tuple(map(float,world.findtext("model[@name='tree_stump']/pose").split()[:2]))
            self.assertLess(math.dist(xy,SUMMIT.route.world(*DEFAULT_STUMP)), .001)
        route = SUMMIT.route
        self.assertLess(math.dist(route.world(route.length),(-39.76,-35.37)), .04)
        self.assertLess(abs(route.local(-33.36,-18.01)[1]), .04)
        n = math.ceil(route.length)
        heights = [self.terrain.height_at(*route.world(i*route.length/n)) for i in range(n+1)]
        self.assertTrue(all(b>a for a,b in zip(heights,heights[1:])))
        self.assertGreater(heights[-1]-heights[0],5.)

    def test_curve_station_and_deadlines(self):
        route = SUMMIT.route
        for i in range(101):
            s = route.length*i/100.
            station, offset = route.local(*route.world(s))
            self.assertAlmostEqual(station, s, places=5)
            self.assertAlmostEqual(offset, 0., places=5)
        self.assertTrue(timeout_reason(150.104, .1, 0.).startswith("simulation_time_limit"))
        self.assertTrue(timeout_reason(12., .1, 8.1).startswith("clock_stalled"))


if __name__ == "__main__":
    unittest.main()
