"""Offline tests for the independent navigation/safety arbitration boundary."""
import math
from types import SimpleNamespace
import unittest
from jarcrac_cooperative_control import Motion,State,STOP
from jarcrac_summit_route import SUMMIT
from camino_safety_logic import RouteFollower,SafetySupervisor,scan_corridor,MAX_TILT
from camino_safety_scene import (crossing_position,CROSSING_START_TIME,
                                  CROSSING_START_D,CROSSING_END_D)


def pose_at(s,stamp=22.):
    x,y,yaw=SUMMIT.route.at(s)
    return State(stamp,x,y,yaw,vx=.20*math.cos(yaw),vy=.20*math.sin(yaw))


def front(s,stamp=22.,obstacle_s=None,obstacle_d=0.):
    ox,oy,yaw=SUMMIT.route.at(s)
    hazard=[math.inf]*181
    if obstacle_s is not None:
        x,y=SUMMIT.route.world(obstacle_s,obstacle_d)
        angle=math.remainder(math.atan2(y-oy,x-ox)-yaw,math.tau)
        i=round((angle+math.pi/2)/(math.pi/180))
        if 0<=i<181:hazard[i]=math.hypot(x-ox,y-oy)
    return SimpleNamespace(stamp=stamp,x=ox,y=oy,yaw=yaw,hazard=tuple(hazard))


class SafetyLogicTest(unittest.TestCase):
    def test_nominal_follower_moves_when_clear(self):
        cmd=RouteFollower().command(22.,pose_at(5.))
        self.assertGreater(cmd.speed,.16)
        self.assertLessEqual(cmd.speed,.30)

    def test_sensor_obstacle_is_detected_in_route(self):
        found=scan_corridor(front(5.,obstacle_s=9.))
        self.assertIsNotNone(found)
        self.assertAlmostEqual(found[0],4.,delta=.2)

    def test_lateral_object_outside_corridor_is_not_emergency(self):
        self.assertIsNone(scan_corridor(front(5.,obstacle_s=9.,obstacle_d=3.)))

    def test_safety_overrides_positive_nominal_command(self):
        supervisor=SafetySupervisor();nominal=Motion(.25,0.)
        result=supervisor.arbitrate(22.,pose_at(5.),front(5.,obstacle_s=9.),nominal)
        self.assertEqual(result.mode,'EMERGENCY_BRAKE')
        self.assertEqual(result.applied,STOP)
        self.assertTrue(result.override)

    def test_recovery_requires_clear_hold(self):
        supervisor=SafetySupervisor();nominal=Motion(.20,0.)
        supervisor.arbitrate(22.,pose_at(5.),front(5.,obstacle_s=9.),nominal)
        for t in (22.2,23.):
            result=supervisor.arbitrate(t,pose_at(5.,t),front(5.,t),nominal)
            self.assertEqual(result.mode,'CLEARANCE_HOLD')
        result=supervisor.arbitrate(23.5,pose_at(5.,23.5),front(5.,23.5),nominal)
        self.assertEqual(result.mode,'NAVIGATION')
        self.assertEqual(result.applied,nominal)

    def test_missing_scan_is_fail_closed(self):
        result=SafetySupervisor().arbitrate(22.,pose_at(5.),None,Motion(.2,0.))
        self.assertEqual(result.mode,'SENSOR_FAIL_SAFE')
        self.assertEqual(result.applied,STOP)

    def test_old_scan_is_fail_closed(self):
        result=SafetySupervisor().arbitrate(22.,pose_at(5.),front(5.,stamp=21.),Motion(.2,0.))
        self.assertEqual(result.mode,'SENSOR_FAIL_SAFE')
        self.assertEqual(result.applied,STOP)

    def test_excessive_tilt_is_fail_closed(self):
        p=pose_at(5.)
        tilted=State(p.stamp,p.x,p.y,p.yaw,p.vx,p.vy,roll=MAX_TILT+.01)
        result=SafetySupervisor().arbitrate(22.,tilted,front(5.),Motion(.2,0.))
        self.assertEqual(result.mode,'STATE_FAIL_SAFE')
        self.assertEqual(result.applied,STOP)

    def test_crossing_schedule_is_up_and_away(self):
        from jarcrac_summit_route import summit_terrain
        terrain=summit_terrain()
        x,y,z,done=crossing_position(SUMMIT,terrain,0.)
        station,offset=SUMMIT.route.local(x,y)
        self.assertAlmostEqual(offset,CROSSING_START_D,delta=.1)
        self.assertFalse(done)
        x,y,z,done=crossing_position(SUMMIT,terrain,100.)
        station,offset=SUMMIT.route.local(x,y)
        self.assertAlmostEqual(offset,CROSSING_END_D,delta=.1)
        self.assertTrue(done)

    def test_safety_score_uses_pose_separate_from_controller(self):
        from camino_safety_score import Score
        score=Score()
        self.assertFalse(score.result()['geometry_passed'])


if __name__=='__main__':unittest.main(verbosity=2)
