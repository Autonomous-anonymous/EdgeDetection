"""CAMINO standalone independent safety-supervisor demo ZIP application."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile


def main():
    args=sys.argv[1:]
    if args in (['-h'],['--help']):
        print('Run from the CAMINO repository checkout:\n'
              '  python3 camino-safety-supervisor.zip demo [--out DIR]\n'
              '  python3 camino-safety-supervisor.zip loop --laps 2\n'
              '  python3 camino-safety-supervisor.zip prepare /tmp/safety-preview.sdf\n'
              '  python3 camino-safety-supervisor.zip test\n'
              'Use demo --help for physics, RTF and other options.')
        return 0
    if not args or args[0].startswith('-'):args=['demo',*args]
    source=Path.cwd()/'edge-path-project/gazebo/scripts'
    needed=('jarcrac_compact_sil.py','jarcrac_cooperative_sil.py',
            'jarcrac_showcase_scene.py','jarcrac_convoy_score.py')
    if not all((source/n).is_file() for n in needed):
        print('Run from your CAMINO checkout (e.g. ~/camino-desktop or ~/camino-summit-test).',
              file=sys.stderr);return 2
    if args[0] in ('demo','loop') and not any(x=='--out' or x.startswith('--out=') for x in args) and not ({'-h','--help'} & set(args)):
        root=Path(tempfile.mkdtemp(prefix='camino-safety-'))
        args+=['--out',str(root/('lap' if args[0]=='demo' else 'laps'))]
    with tempfile.TemporaryDirectory(prefix='camino-safety-source-') as tmp:
        code=Path(tmp)
        with zipfile.ZipFile(Path(sys.argv[0]).resolve()) as archive:
            for name in archive.namelist():
                p=Path(name)
                if p.parent.as_posix()=='src' and p.suffix=='.py':
                    (code/p.name).write_bytes(archive.read(name))
            if args[0]=='test':
                script='test_safety_logic.py'
                (code/script).write_bytes(archive.read('tests/'+script))
                args=[]
            else:script='camino_safety_trial.py'
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
        env['PYTHONPATH']=os.pathsep.join(filter(None,(str(code),str(source),env.get('PYTHONPATH'))))
        try:
            return subprocess.run([sys.executable,'-u',str(code/script),*args],env=env).returncode
        except KeyboardInterrupt:return 130

if __name__=='__main__':
    raise SystemExit(main())
