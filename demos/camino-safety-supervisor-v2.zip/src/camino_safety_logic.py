"""Pure SIL safety supervisor: no Gazebo dependency and no ground-truth obstacle input.

Navigation is deliberately independent of the sensor safety layer. Only the final
motion arbiter publishes requests to the existing CAMINO relay.
"""
from dataclasses import dataclass
import math
from jarcrac_cooperative_control import STOP, Motion, angle_error, tracked_command, AGE_LIMIT
from jarcrac_summit_route import SUMMIT

MAX_TILT = math.radians(8.)
HAZARD_AHEAD_M = 5.6
HAZARD_LATERAL_M = 1.85
CLEAR_HOLD_S = 1.20
MAX_SCANNER_AGE_S = AGE_LIMIT

@dataclass(frozen=True)
class SafetyDecision:
    requested: Motion
    applied: Motion
    mode: str
    hazard_range_m: float | None
    hazard_offset_m: float | None
    override: bool


class RouteFollower:
    """Low-speed nominal planner which intentionally ignores obstacle scans."""
    def __init__(self, route=SUMMIT.route):
        self.route = route
        self.goal_since = None
        self.arrived = False

    def command(self, now, pose):
        if self.arrived:
            return STOP
        progress, offset = self.route.local(pose.x, pose.y)
        goal_x, goal_y = self.route.world(self.route.length)
        goal_distance = math.dist((pose.x, pose.y), (goal_x, goal_y))
        if goal_distance <= .62:
            if self.goal_since is None:
                self.goal_since = now
            if goal_distance <= .62 and now-self.goal_since >= 1.2 and pose.speed <= .055:
                self.arrived = True
            return STOP
        self.goal_since = None
        lookahead = min(self.route.length, max(0., progress)+1.20)
        x, y = self.route.world(lookahead)
        dx, dy = x-pose.x, y-pose.y
        distance = math.hypot(dx, dy)
        if distance < .03:
            return STOP
        error = angle_error(math.atan2(dy, dx), pose.yaw)
        if abs(error) > .95 or abs(offset) > 1.2:
            return STOP
        curvature = min(.70, max(-.70, 2*math.sin(error)/max(.60, distance)))
        # Stay below the existing tracked relay's 0.30 m/s speed limit.
        speed = min(.27, max(.055, goal_distance*.30))
        return tracked_command(speed, curvature)


def scan_corridor(scan, route=SUMMIT.route):
    """Find nearest elevated LiDAR return in the narrow forward route corridor.

    No Gazebo obstacle pose, predicted actor schedule, or ground truth enters
    this decision. The scan comes from the existing ground-filtered LiDAR stage.
    """
    if scan is None:
        return None
    current_s, _ = route.local(scan.x, scan.y)
    best = None
    for i, distance in enumerate(scan.hazard):
        if not math.isfinite(distance) or not .3 < distance <= 8.:
            continue
        angle = scan.yaw-math.pi/2+i*math.pi/180
        x = scan.x + distance*math.cos(angle)
        y = scan.y + distance*math.sin(angle)
        station, offset = route.local(x, y)
        ahead = station-current_s
        if not .35 <= ahead <= HAZARD_AHEAD_M or abs(offset) > HAZARD_LATERAL_M:
            continue
        if best is None or ahead < best[0]:
            best = ahead, offset
    return best


class SafetySupervisor:
    """Fail-closed override with sensor freshness and clearing hysteresis."""
    def __init__(self):
        self.hazard_seen = False
        self.clear_since = None
        self.last_mode = None
        self.overrides = 0

    def arbitrate(self, now, pose, scan, nominal):
        bad_state = now is None or pose is None or not pose.fresh(now, MAX_TILT)
        bad_scan = (scan is None or now is None or
                    not -0.02 <= now-scan.stamp <= MAX_SCANNER_AGE_S)
        threat = scan_corridor(scan) if not bad_state and not bad_scan else None
        if bad_state or bad_scan:
            mode = "SENSOR_FAIL_SAFE" if bad_scan else "STATE_FAIL_SAFE"
            self.clear_since = None
        elif threat is not None:
            mode = "EMERGENCY_BRAKE"
            self.hazard_seen = True
            self.clear_since = None
        elif self.hazard_seen:
            if self.clear_since is None:
                self.clear_since = now
            if now-self.clear_since < CLEAR_HOLD_S:
                mode = "CLEARANCE_HOLD"
            else:
                mode = "NAVIGATION"
                self.hazard_seen = False
        else:
            mode = "NAVIGATION"
        applied = nominal if mode == "NAVIGATION" else STOP
        override = nominal.speed > .025 and applied == STOP
        if override:
            self.overrides += 1
        self.last_mode = mode
        return SafetyDecision(nominal, applied, mode, threat[0] if threat else None,
                              threat[1] if threat else None, override)
