"""Independent Gazebo-pose evaluation; no controller commands used to score clearance."""
import json
import math
import signal
import threading
import time
from jarcrac_cooperative_control import State, angle_error
from jarcrac_cooperative_geometry import model_footprints
from jarcrac_cooperative_sil import NAMES, angles, stamp_of
from final_sil_v6_checks import polygon_distance
from jarcrac_summit_route import SUMMIT
from camino_safety_scene import (WORLD,HAZARD_NAME,HAZARD_SIZE,CROSSING_S,
                                  CROSSING_END_D,CROSSING_START_TIME,CROSSING_SPEED_MPS,
                                  CROSSING_START_D)


def hazard_polygon(x,y):
    h = HAZARD_SIZE/2
    return ((x-h,y-h),(x+h,y-h),(x+h,y+h),(x-h,y+h))


class Score:
    def __init__(self, shape=None):
        self.shape = shape or model_footprints()[0]
        self.last_pose = None
        self.start_sim = None
        self.samples = 0
        self.min_clearance = math.inf
        self.peak_pitch = self.peak_roll = 0.0
        self.min_s = math.inf
        self.max_s = -math.inf
        self.first_stop_s = self.stop_since = self.stop_duration = None
        self.hazard_start_seen = self.hazard_finished = False
        self.resume_verified = self.goal_since = self.goal_held = None
        self.motion_before_stop = False
        self.collision_flag = self.coverage_gap = False
        self.max_backward = 0.0
        self.goal_position = SUMMIT.route.world(SUMMIT.route.length)
        self.last_reported = None

    def observe(self, pose, hazard):
        if self.last_pose is not None:
            dt = pose.stamp-self.last_pose.stamp
            if dt <= 0:
                self.coverage_gap |= dt < 0
                return
            if dt < .07:
                return
            self.coverage_gap |= dt > .55
            speed = math.dist((pose.x,pose.y),(self.last_pose.x,self.last_pose.y))/dt
        else:
            speed = 0.
            self.start_sim = pose.stamp
            dt = 0.
        previous = self.last_pose
        self.last_pose = pose
        self.samples += 1
        self.peak_pitch = max(self.peak_pitch,abs(pose.pitch))
        self.peak_roll = max(self.peak_roll,abs(pose.roll))
        station,offset = SUMMIT.route.local(pose.x,pose.y)
        self.min_s=min(self.min_s,station)
        self.max_s=max(self.max_s,station)
        if previous:
            prev_s=SUMMIT.route.local(previous.x,previous.y)[0]
            self.max_backward=max(self.max_backward,max(0.,prev_s-station))
        gap = polygon_distance(self.shape.at(pose),hazard_polygon(hazard.x,hazard.y))
        self.min_clearance = min(self.min_clearance, gap)
        self.collision_flag |= gap <= 0.
        obstacle_s,obstacle_d=SUMMIT.route.local(hazard.x,hazard.y)
        self.hazard_start_seen |= (abs(obstacle_s-CROSSING_S) < .9 and
                                   obstacle_d > CROSSING_START_D+1.)
        self.hazard_finished |= obstacle_d >= CROSSING_END_D-.3
        if self.first_stop_s is None and station>=2.:
            self.motion_before_stop |= speed > .14
            # Stop is meaningful only near the crossing while the hazard is in or
            # approaching the route corridor; use measured actor positions.
            near = (0 <= obstacle_s-station <= 7.0 and
                    abs(obstacle_d) <= 2.4 and not self.hazard_finished)
            if near and speed <= .065:
                if self.stop_since is None:
                    self.stop_since = pose.stamp
                if pose.stamp-self.stop_since >= .45:
                    self.first_stop_s = station
                    self.stop_duration = pose.stamp-self.stop_since
            else:
                self.stop_since = None
        elif self.first_stop_s is not None and self.resume_verified is None:
            if self.hazard_finished and station>=self.first_stop_s+.8 and speed>=.10:
                self.resume_verified = (pose.stamp,station)
        distance = math.dist((pose.x,pose.y),self.goal_position)
        if distance <= .70 and speed <= .07:
            if self.goal_since is None:
                self.goal_since=pose.stamp
            self.goal_held = pose.stamp-self.goal_since
        else:
            self.goal_since=None
            self.goal_held=None

    @property
    def finished(self):
        return self.goal_held is not None and self.goal_held>=.7

    def result(self):
        p=self.last_pose
        s=SUMMIT.route.local(p.x,p.y)[0] if p else None
        duration=p.stamp-self.start_sim if p else None
        constraints={
            'start_observed': self.min_s <= .45,
            'moving_hazard_observed': self.hazard_start_seen and self.hazard_finished,
            'hazard_stop_verified': self.first_stop_s is not None,
            'resumption_verified': self.resume_verified is not None,
            'goal_stopped': self.finished,
            'minimum_gap_passed': self.min_clearance >= 1.0,
            'tilt_passed': math.degrees(self.peak_pitch) <= 8. and math.degrees(self.peak_roll)<=8.,
            'no_collision': not self.collision_flag,
            'coverage_passed': not self.coverage_gap,
            'sim_time_passed': duration is not None and duration <= 150.,
            'forward_progress_passed': self.motion_before_stop and self.max_s >= SUMMIT.route.length-.8,
        }
        result={
            'geometry_passed': all(constraints.values()),
            'checks':constraints, 'duration_sim_s':duration,
            'minimum_hazard_footprint_gap_m':self.min_clearance if math.isfinite(self.min_clearance) else None,
            'max_abs_pitch_deg':math.degrees(self.peak_pitch),
            'max_abs_roll_deg':math.degrees(self.peak_roll),
            'pose_samples':self.samples,'coverage_gap':self.coverage_gap,
            'hazard_stop_verified':constraints['hazard_stop_verified'],
            'resumption_verified':constraints['resumption_verified'],
            'goal_stopped':constraints['goal_stopped'],
            'hazard_crossing_completed':self.hazard_finished,
            'stop_station_m':self.first_stop_s,
            'resume_station_m':self.resume_verified[1] if self.resume_verified else None,
            'stationary_at_goal_s':self.goal_held,
            'final_goal_distance_m':math.dist((p.x,p.y),self.goal_position) if p else None,
            'max_backward_step_m':self.max_backward,
        }
        return result


def evaluate(report, ready, timeout, *, target_rtf=1.5):
    from gz.msgs10.pose_v_pb2 import Pose_V
    from gz.transport13 import Node
    node,score=Node(),Score()
    lock,ending=threading.Lock(),threading.Event()
    latest={}
    def receive(message):
        stamp=stamp_of(message)
        if stamp is None: return
        found={}
        for model in message.pose:
            name=model.name.rsplit('::',1)[-1]
            if name not in (NAMES[0],HAZARD_NAME): continue
            point=model.position
            if not all(map(math.isfinite,(point.x,point.y,point.z))):continue
            try: roll,pitch,yaw=angles(model.orientation)
            except ValueError: continue
            found[name]=State(stamp,point.x,point.y,yaw,roll=roll,pitch=pitch,z=point.z)
        with lock: latest.update(found)
    if not node.subscribe(Pose_V,f'/world/{WORLD}/pose/info',receive):
        raise RuntimeError('Cannot subscribe independent safety evaluator to world poses')
    signal.signal(signal.SIGTERM,lambda *_:ending.set())
    ready.touch()
    deadline=time.monotonic()+timeout
    while not ending.wait(.02/max(1.,target_rtf)) and time.monotonic()<deadline:
        with lock: vehicle,hazard=(latest.get(n) for n in (NAMES[0],HAZARD_NAME))
        if vehicle is None or hazard is None:continue
        score.observe(vehicle,hazard)
        if score.finished:break
    report.write_text(json.dumps(score.result(),indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return score.result()['geometry_passed']
