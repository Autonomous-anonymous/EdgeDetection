"""Independent simulated moving hazard driver; all service calls are acknowledged."""
import json
import math
import signal
import threading
import time
from camino_safety_scene import (WORLD,HAZARD_NAME,CROSSING_END_D,CROSSING_START_TIME,
                                  CROSSING_SPEED_MPS,CROSSING_START_D,crossing_position)
from jarcrac_summit_route import SUMMIT,summit_terrain


def run(ready, report, timeout):
    from gz.msgs10.clock_pb2 import Clock
    from gz.msgs10.pose_v_pb2 import Pose_V
    from gz.msgs10.pose_pb2 import Pose
    from gz.msgs10.boolean_pb2 import Boolean
    from gz.transport13 import Node
    node,lock,stop=Node(),threading.Lock(),threading.Event()
    status={'sim':None,'actor':None,'actor_seq':0}
    def clock(msg):
        with lock: status['sim']=msg.sim.sec+msg.sim.nsec*1e-9
    def poses(msg):
        for p in msg.pose:
            if p.name.rsplit('::',1)[-1] == HAZARD_NAME:
                with lock:
                    status['actor']=(p.position.x,p.position.y,p.position.z)
                    status['actor_seq']+=1
                return
    if not node.subscribe(Clock,f'/world/{WORLD}/clock',clock):
        raise RuntimeError('Cannot subscribe to hazard clock')
    if not node.subscribe(Pose_V,f'/world/{WORLD}/pose/info',poses):
        raise RuntimeError('Cannot subscribe to hazard pose')
    signal.signal(signal.SIGTERM,lambda *_:stop.set())
    ready.touch()
    deadline=time.monotonic()+timeout
    last_requested=-math.inf
    deliveries=errors=verified=0
    last_point=None
    pose_service_used=None;request_issues=[]
    first_moved=finished=None
    failure=None
    terrain=summit_terrain()
    while not stop.is_set() and time.monotonic()<deadline:
        with lock: now,measured,seq=status['sim'],status['actor'],status['actor_seq']
        if now is None or measured is None or now<CROSSING_START_TIME or now-last_requested<.30:
            stop.wait(.03)
            continue
        target_done=False
        try:
            command_time=now if last_point is None else min(now,last_requested+1.0)
            x,y,z,target_done=crossing_position(SUMMIT,terrain,command_time)
            if last_point is not None and math.dist((x,y,z),last_point)>.45:
                raise RuntimeError('Hazard pose step exceeded 0.45 m; refusing an unsafe teleport')
            request=Pose_V()
            pose=request.pose.add()
            pose.name=HAZARD_NAME
            pose.position.x,pose.position.y,pose.position.z=x,y,z
            pose.orientation.w=1.0
            # A pose service can occasionally time out. Retry a bounded number
            # of times, then use the equivalent single-model set_pose service.
            # Neither a timeout nor a negative response counts as success.
            acknowledged=False
            modes=('single','vector') if pose_service_used=='single' else ('vector','single')
            for mode in modes:
                if acknowledged:break
                for attempt in range(3):
                    if mode=='vector':
                        payload,kind=request,Pose_V
                    else:
                        payload,kind=Pose(),Pose
                        payload.name=HAZARD_NAME
                        payload.position.x,payload.position.y,payload.position.z=x,y,z
                        payload.orientation.w=1.0
                    try:
                        ok,response=node.request(
                            f'/world/{WORLD}/'+('set_pose' if mode=='single' else 'set_pose_vector'),
                            payload,kind,Boolean,600)
                        cause=('timeout/unavailable' if not ok else
                               'negative/empty response' if response is None or not response.data
                               else None)
                    except Exception as exc:
                        cause=f'{type(exc).__name__}: {exc}'
                    deliveries+=1
                    if cause is None:
                        acknowledged=True
                        pose_service_used=mode
                        break
                    request_issues.append(f'{mode} attempt {attempt+1}: {cause}')
                    stop.wait(.18)
            if not acknowledged:
                raise RuntimeError('Gazebo did not acknowledge any moving-hazard pose service: '+
                                   '; '.join(request_issues[-6:]))
            last_point=(x,y,z)
            last_requested=command_time
            if first_moved is None:first_moved=now
            # Pose verification is independent of the service acknowledgment.
            until=time.monotonic()+1.0
            valid=False
            while not stop.is_set() and time.monotonic()<until:
                with lock: observed,latest_seq=status['actor'],status['actor_seq']
                if latest_seq>seq and observed is not None and math.dist(observed,(x,y,z)) <= .16:
                    verified+=1;valid=True;break
                stop.wait(.035)
            if not valid:
                raise RuntimeError('Moving hazard pose was not confirmed by Gazebo pose info')
            if target_done and finished is None:finished=now
        except Exception as exc:
            errors+=1;failure=str(exc)
            print('Hazard driver error:',failure,flush=True)
            break
        if finished is not None:
            # Keep the actor in its final safe position while other processes run.
            stop.wait(.1)
            while not stop.is_set() and time.monotonic()<deadline:stop.wait(.10)
            break
    report.write_text(json.dumps({'first_moved_sim_s':first_moved,
       'completed_sim_s':finished,'pose_requests':deliveries,
       'verified_poses':verified,'errors':errors,'failure':failure,
       'last_pose_service':pose_service_used,
       'service_request_failures':request_issues[-12:],
       'complete':finished is not None and errors==0},indent=2)+'\n')
    if failure:raise RuntimeError(failure)
