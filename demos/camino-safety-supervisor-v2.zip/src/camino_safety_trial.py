#!/usr/bin/env python3
"""Standalone safety supervisor + independently driven moving hazard SIL trial."""
import argparse
from functools import partial
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import uuid
import zipfile
import xml.etree.ElementTree as ET

from jarcrac_compact_sil import REQUEST_PAIR, reap, relay
from jarcrac_cooperative_control import AGE_LIMIT, STOP
from jarcrac_cooperative_geometry import GAZEBO, MODELS, model_footprints
from jarcrac_cooperative_sil import EXTERNAL_STATE, LIDAR, SIM_STATE, Inputs, insert_vehicles
from jarcrac_cooperative_terrain import WORLD_FRAME, scan_from_message
from jarcrac_summit_route import SUMMIT, summit_terrain
from camino_safety_scene import WORLD, safety_scene
from camino_safety_logic import MAX_TILT, RouteFollower, SafetySupervisor
from camino_safety_score import evaluate
from camino_safety_hazard import run as hazard_worker


def prepare(output, *, physics_step=.002, target_rtf=1.5, show_lidar=True):
    tree=ET.parse(GAZEBO/'worlds/ruskotunturi_final_sil_demo_v6_world.sdf')
    world=tree.getroot().find('world')
    world.set('name',WORLD)
    world.find('physics/max_step_size').text=str(physics_step)
    world.find('physics/real_time_factor').text=str(target_rtf)
    for name in ('aeb_vehicle_360','aeb_vehicle_360_b'):
        existing=world.find(f"include[name='{name}']")
        if existing is None:raise RuntimeError(f'Missing template vehicle include {name}')
        world.remove(existing)
    for model in world.findall('model'):
        world.remove(model)
    terrain=summit_terrain()
    insert_vehicles(world,terrain,(SUMMIT.start(0),),(0.,),SUMMIT.frame,vehicle_indices=(0,))
    safety_scene(world,terrain,SUMMIT,show_lidar=show_lidar)
    ET.indent(tree,space='  ')
    with output.open('xb') as out:tree.write(out,encoding='utf-8',xml_declaration=True)


def trace_evidence(path):
    stats={'supervisor_override_count':0,'hazard_override_count':0,
           'nominal_command_samples':0,'resume_after_hazard':False,
           'sensor_fail_safe_count':0,'emergency_brake_seen':False,
           'moving_hazard_sensor_ranges':0}
    hazard=False;clear=False
    with path.open() as stream:
        for line in stream:
            row=json.loads(line)
            if row['nominal_speed']>.025:stats['nominal_command_samples']+=1
            if row['supervisor_mode'] in ('STATE_FAIL_SAFE','SENSOR_FAIL_SAFE'):
                stats['sensor_fail_safe_count']+=1
            if row['supervisor_mode']=='EMERGENCY_BRAKE':
                hazard=True;stats['emergency_brake_seen']=True
                if row['hazard_range_m'] is not None:stats['moving_hazard_sensor_ranges']+=1
            if row['supervisor_mode']=='CLEARANCE_HOLD':clear=True
            if row['override']:
                stats['supervisor_override_count']+=1
                if row['supervisor_mode']=='EMERGENCY_BRAKE':stats['hazard_override_count']+=1
            if (hazard and clear and row['supervisor_mode']=='NAVIGATION'
                    and row['applied_speed']>.025):stats['resume_after_hazard']=True
    stats['trace_passed']=(stats['hazard_override_count']>=2
                           and stats['moving_hazard_sensor_ranges']>=2
                           and stats['resume_after_hazard'])
    return stats


def control(trace, processes, deadline, *, target_rtf, timing):
    from gz.msgs10.clock_pb2 import Clock
    from gz.msgs10.double_v_pb2 import Double_V
    from gz.msgs10.laserscan_pb2 import LaserScan
    from gz.msgs10.odometry_pb2 import Odometry
    from gz.transport13 import Node
    node=Node()
    inputs=Inputs(WORLD_FRAME,2,MAX_TILT)
    publisher=node.advertise(REQUEST_PAIR,Double_V)
    for kind,topic,callback in ((Clock,f'/world/{WORLD}/clock',inputs.clock_sample),
                               (Odometry,SIM_STATE[0],partial(inputs.vehicle_sample,0)),
                               (LaserScan,LIDAR,partial(inputs.lidar_sample,index=0))):
        if not node.subscribe(kind,topic,callback):raise RuntimeError(f'Cannot subscribe {topic}')
    def publish(cmd):
        msg=Double_V()
        msg.data.extend((cmd.speed,cmd.yaw_rate,0.,0.))
        publisher.publish(msg)
    route,supervisor=RouteFollower(),SafetySupervisor()
    terrain=summit_terrain()
    last_scan_stamp=None;front=None
    last_clock=None;last_clock_wall=time.monotonic();started=time.monotonic()
    previous_mode=None;previous_progress=-1.
    start_sim=None
    interval=.05/max(1.,target_rtf)
    try:
        while time.monotonic()<deadline:
            wall_now=time.monotonic()
            for name,process in processes.items():
                status=process.poll()
                if status is not None and (name != 'evaluator' or status != 0):
                    raise RuntimeError(f'{name} exited with status {status}; see its log')
            now,pose,_,frames,reset=inputs.snapshot_all()
            if reset:raise RuntimeError('Gazebo clock reset')
            if now is not None and now!=last_clock:
                last_clock,last_clock_wall=now,wall_now
                timing['first']=timing['first'] or (now,wall_now)
                timing['last']=(now,wall_now)
            if wall_now-last_clock_wall>9.0:raise RuntimeError('Gazebo clock stalled')
            raw=frames[0]
            if raw is None:
                front=None
            elif raw[1]!=last_scan_stamp:
                front=scan_from_message(raw[0],raw[1],raw[2],terrain,WORLD_FRAME)
                last_scan_stamp=raw[1]
            if now is None or pose is None or not pose.fresh(now,MAX_TILT):
                nominal=STOP
            elif start_sim is None:
                nominal=STOP
                if front is not None and pose.speed<.055:
                    start_sim=now
            elif now-start_sim<1.1:
                nominal=STOP
            else:
                nominal=route.command(now,pose)
            decision=supervisor.arbitrate(now,pose,front,nominal)
            publish(decision.applied)
            station,offset=(SUMMIT.route.local(pose.x,pose.y) if pose is not None else (None,None))
            row={'sim_s':now,'station_m':station,'offset_m':offset,
                 'vehicle_speed_mps':pose.speed if pose is not None else None,
                 'nominal_speed':decision.requested.speed,
                 'nominal_yaw_rate':decision.requested.yaw_rate,
                 'applied_speed':decision.applied.speed,
                 'applied_yaw_rate':decision.applied.yaw_rate,
                 'supervisor_mode':decision.mode,'override':decision.override,
                 'hazard_range_m':decision.hazard_range_m,
                 'hazard_offset_m':decision.hazard_offset_m}
            print(json.dumps(row,allow_nan=False),file=trace,flush=True)
            if decision.mode!=previous_mode:
                print(f"sim {now}   SAFETY {decision.mode}   "
                      f"nominal {decision.requested.speed:.2f} -> applied {decision.applied.speed:.2f}"
                      +(f"   hazard {decision.hazard_range_m:.2f}m" if decision.hazard_range_m is not None else '')
                      +(f"   route {station:.2f}m" if station is not None else ''),flush=True)
                previous_mode=decision.mode
            if now is not None and start_sim is not None and now-start_sim>149.:
                raise RuntimeError('simulation_time_limit (149 s allowed for safety demo)')
            if route.arrived:
                return
            if time.monotonic()-started>50. and start_sim is None:
                raise RuntimeError('Initial fresh odometry or front-LiDAR unavailable')
            time.sleep(max(0.,interval-(time.monotonic()-wall_now)))
        raise RuntimeError('wall-clock deadline reached')
    finally:
        for _ in range(6):publish(STOP);time.sleep(interval)


def demo(args):
    start=time.monotonic()
    deadline=start+args.wall_timeout
    gz=shutil.which('gz')
    if not gz:raise RuntimeError('Gazebo Harmonic with the gz command is required')
    __import__('gz.msgs10.odometry_pb2');__import__('gz.transport13')
    out=args.out.resolve()
    out.mkdir(parents=True,exist_ok=False)
    print(f'Recording safety supervisor lap in {out}',flush=True)
    world,trace,report,hazards=(out/n for n in ('world.sdf','control.jsonl','evaluation.json','hazard.json'))
    prepare(world,physics_step=args.physics_step,target_rtf=args.target_rtf,
            show_lidar=not args.no_lidar_view)
    os.environ['GZ_PARTITION']='camino_safety_'+uuid.uuid4().hex
    os.environ['GZ_SIM_RESOURCE_PATH']=os.pathsep.join(filter(None,
                    (str(MODELS),os.environ.get('GZ_SIM_RESOURCE_PATH'))))
    print(f"Gazebo partition {os.environ['GZ_PARTITION']}",flush=True)
    print(f'Physics step {args.physics_step:g} s   Requested RTF {args.target_rtf:g}',flush=True)
    processes={};failure=None;timing={'first':None,'last':None}
    def worker(name,cmd):
        with (out/f'{name}.log').open('xb') as stream:
            child=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        processes[name]=child
        return child
    try:
        for name,path in (('relay',report),('evaluator',report),('hazard',hazards)):
            ready=out/f'.{name}-ready'
            child=worker(name,[sys.executable,str(Path(__file__).resolve()),name,
                               str(ready),str(path),str(max(0.,deadline-time.monotonic())),
                               '--target-rtf',str(args.target_rtf)])
            until=min(deadline,time.monotonic()+15.)
            while not ready.exists() and child.poll() is None and time.monotonic()<until:
                time.sleep(.05)
            if not ready.exists():
                raise RuntimeError(f'{name} did not start; see {out/(name+".log")}')
            ready.unlink()
        mode=['-s','--headless-rendering'] if args.headless else []
        worker('gazebo',[gz,'sim','-r',*mode,str(world)])
        with trace.open('x') as stream:
            control(stream,processes,deadline-min(5.,args.wall_timeout*.08),
                    target_rtf=args.target_rtf,timing=timing)
        # The evaluator is a separate process, allow it to settle and write.
        processes['evaluator'].wait(timeout=max(0.,min(8.,deadline-time.monotonic()-1.)))
    except (RuntimeError,OSError,ValueError,subprocess.TimeoutExpired,KeyboardInterrupt) as exc:
        failure=str(exc) or type(exc).__name__
    finally:
        for name in ('gazebo','evaluator','hazard','relay'):
            reap(processes.get(name),grace=max(0.,min(4.,deadline-time.monotonic())))
    # Evaluator/hazard workers write reports when terminated.
    geometry=json.loads(report.read_text()) if report.exists() else {}
    hazard=json.loads(hazards.read_text()) if hazards.exists() else {}
    trace_stats=trace_evidence(trace) if trace.exists() else {}
    first,last=timing['first'],timing['last']
    rtf=round((last[0]-first[0])/(last[1]-first[1]),3) if first and last and last[1]>first[1] else None
    wall_elapsed=round(time.monotonic()-start,3)
    passed=(failure is None and wall_elapsed<=300. and geometry.get('geometry_passed',False)
            and hazard.get('complete',False) and trace_stats.get('trace_passed',False))
    result={'passed':bool(passed),'failure':failure,'scenario':'independent_safety_moving_hazard',
            'state_source':'gazebo-odometry','physics_step':args.physics_step,
            'target_rtf':args.target_rtf,'observed_rtf':rtf,'wall_elapsed_s':wall_elapsed,
            **geometry,'hazard_driver':hazard,'supervision':trace_stats}
    if not passed and failure is None:
        result['failure']='Independent safety, Gazebo geometry, or hazard criterion failed'
    (out/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(f"{'PASS' if passed else 'FAIL'}  {out/'result.json'}",flush=True)
    print('Measured safety demonstration:',flush=True)
    for k in ('duration_sim_s','minimum_hazard_footprint_gap_m','hazard_stop_verified',
              'resumption_verified','goal_stopped','max_abs_pitch_deg','max_abs_roll_deg'):
        print(f'  {k} = {geometry.get(k)}',flush=True)
    print(f"  hazard_override_count = {trace_stats.get('hazard_override_count')}",flush=True)
    print(f"  hazard_pose_verified = {hazard.get('verified_poses')}",flush=True)
    archive=out/'safety-reports.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
        for name in ('result.json','evaluation.json','hazard.json','control.jsonl',
                     'evaluator.log','hazard.log','relay.log'):
            if (out/name).exists():bundle.write(out/name,name)
    print(f'Reports to attach: {archive}',flush=True)
    return passed


def play_loop(args):
    lap=1
    args.out.mkdir(parents=True,exist_ok=True)
    while args.laps is None or lap<=args.laps:
        dest=args.out/f'lap-{lap:03d}'
        command=[sys.executable,str(Path(__file__).resolve()),'demo','--out',str(dest),
                 '--physics-step',str(args.physics_step),'--target-rtf',str(args.target_rtf),
                 '--wall-timeout',str(args.wall_timeout)]
        if args.headless:command.append('--headless')
        if args.no_lidar_view:command.append('--no-lidar-view')
        child=subprocess.Popen(command,start_new_session=True)
        try:status=child.wait()
        except KeyboardInterrupt:
            if child.poll() is None:child.send_signal(signal.SIGINT)
            child.wait();return 130
        if status:
            print(f'Safety loop stopped on lap {lap}: {dest}',file=sys.stderr)
            return status
        lap+=1
    return 0


def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='action',required=True)
    pre=sub.add_parser('prepare');pre.add_argument('world',type=Path)
    dem=sub.add_parser('demo');loop=sub.add_parser('loop')
    loop.add_argument('--laps',type=int)
    for item in (pre,dem,loop):
        item.add_argument('--physics-step',type=float,default=.002)
        item.add_argument('--target-rtf',type=float,default=1.5)
        item.add_argument('--no-lidar-view',action='store_true')
    for item in (dem,loop):
        item.add_argument('--out',type=Path,required=True)
        item.add_argument('--wall-timeout',type=float,default=900.)
        item.add_argument('--headless',action='store_true')
    for name in ('relay','evaluator','hazard'):
        w=sub.add_parser(name)
        w.add_argument('ready',type=Path)
        w.add_argument('report',type=Path)
        w.add_argument('timeout',type=float)
        w.add_argument('--target-rtf',type=float,default=1.5)
    a=p.parse_args()
    if a.action in ('demo','loop','prepare'):
        if not math.isfinite(a.physics_step) or not .0005<=a.physics_step<=.002:
            p.error('Physics step must be between 0.0005 and 0.002')
        if not math.isfinite(a.target_rtf) or not .1<=a.target_rtf<=5.:
            p.error('RTF must be from 0.1 to 5.0')
    if a.action in ('demo','loop'):
        if not math.isfinite(a.wall_timeout) or a.wall_timeout <= 0:p.error('Invalid wall timeout')
    if a.action=='loop' and a.laps is not None and a.laps<1:p.error('Laps must be positive')
    try:
        if a.action=='prepare':
            a.world.parent.mkdir(parents=True,exist_ok=True)
            prepare(a.world,physics_step=a.physics_step,target_rtf=a.target_rtf,
                    show_lidar=not a.no_lidar_view)
            print(a.world);return 0
        if a.action=='relay':
            relay(a.ready,SUMMIT,vehicle_indices=(0,));return 0
        if a.action=='evaluator':
            return 0 if evaluate(a.report,a.ready,a.timeout,target_rtf=a.target_rtf) else 1
        if a.action=='hazard':
            hazard_worker(a.ready,a.report,a.timeout);return 0
        if a.action=='loop':return play_loop(a)
        return 0 if demo(a) else 1
    except (OSError,ValueError,RuntimeError,ImportError) as exc:
        p.exit(1,str(exc)+'\n')


if __name__=='__main__':
    raise SystemExit(main())
