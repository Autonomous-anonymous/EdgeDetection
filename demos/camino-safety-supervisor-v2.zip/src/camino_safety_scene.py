"""Use the proven summit route and terrain, but replace its stump with a crossing hazard."""
import math
from jarcrac_cooperative_sil import add
from jarcrac_summit_scene import summit_scene

WORLD = 'camino_independent_safety_demo'
HAZARD_NAME = 'camino_crossing_hazard'
CROSSING_S = 11.0
CROSSING_START_D = -5.4
CROSSING_END_D = 5.4
HAZARD_SIZE = .95
HAZARD_HEIGHT = 1.45
CROSSING_START_TIME = 17.0
CROSSING_SPEED_MPS = .36


def crossing_position(course, terrain, elapsed):
    f = min(1., max(0., (elapsed-CROSSING_START_TIME)*CROSSING_SPEED_MPS /
                        (CROSSING_END_D-CROSSING_START_D)))
    d = CROSSING_START_D+f*(CROSSING_END_D-CROSSING_START_D)
    x,y = course.route.world(CROSSING_S, d)
    z = terrain.height_at(x,y)
    if z is None:
        raise ValueError('Moving obstacle left mapped Ruskotunturi terrain')
    return x,y,z+HAZARD_HEIGHT/2-.015, f >= 1.


def safety_scene(world, terrain, course, show_lidar=True):
    # Reuse exactly the summit camera/goal/route markers, but remove the stump.
    summit_scene(world, terrain, course, (10.5,-.12), show_lidar=show_lidar)
    stump = world.find("model[@name='tree_stump']")
    if stump is None:
        raise ValueError('Expected original stump marker model was not created')
    world.remove(stump)
    x,y,z,_ = crossing_position(course, terrain, 0.0)
    model=add(world,'model',name=HAZARD_NAME)
    add(model,'static','true')
    add(model,'pose',f'{x} {y} {z} 0 0 0')
    link=add(model,'link',name='hazard')
    for role in ('collision','visual'):
        body=add(link,role,name='moving_hazard')
        add(add(add(body,'geometry'),'box'),'size',f'{HAZARD_SIZE} {HAZARD_SIZE} {HAZARD_HEIGHT}')
        if role=='visual':
            material=add(body,'material')
            add(material,'ambient','1 .40 .04 1')
            add(material,'diffuse','1 .40 .04 1')
    # Orange upright barrier with white top to make its crossing visible.
    upper=add(link,'visual',name='white_top')
    add(upper,'pose',f'0 0 {HAZARD_HEIGHT*.32} 0 0 0')
    add(add(add(upper,'geometry'),'box'),'size',f'{HAZARD_SIZE+.02} {HAZARD_SIZE+.02} {.22}')
    material=add(upper,'material')
    add(material,'ambient','1 1 .93 1')
    add(material,'diffuse','1 1 .93 1')
