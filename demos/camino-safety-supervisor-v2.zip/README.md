# CAMINO — independent safety supervisor and moving hazard (experimental SIL)

**Status: experimental v2 — no Gazebo PASS verified for v2.** Developed as a separate fourth demo, not as a replacement for the validated two-vehicle showcase or the two successful JARCRAC uphill courses.

## Scenario

A **detailed-track JARCRAC** follows the existing **27 m curved, gently uphill Ruskotunturi route**. An orange-and-white barrier moves across the route near station 11 m. A normal route follower requests forward motion, while a separate *LiDAR-based safety supervisor* can replace any motion request with `STOP`. Once the crossing is clear for 1.2 simulated seconds, the supervisor releases control and the vehicle continues to a green goal marker.

Unlike the previous summit and convoy demos, **no obstacle detour is attempted**: the focus is on the safety layer's authority to interrupt and release navigation. The moving hazard is a **Gazebo kinematically repositioned box** (not a pedestrian or a second self-driving vehicle). The native Ruskotunturi terrain is unchanged.

## Safety architecture

- The **normal planner** sees vehicle odometry and the static reference route; it **does not access the hazard schedule or obstacle position**.
- The **safety supervisor** sees the latest vehicle state and **ground-filtered 180° LiDAR** only. It checks for observed elevated returns ahead in the nominal route corridor and interrupts movement. It independently fails closed on missing/stale sensors and measured tilt exceeding 8°. Release requires 1.2 s of continuously clear LiDAR.
- The **moving-obstacle driver** uses Gazebo `/world/.../set_pose_vector`, verifies each change against the world's `/pose/info`, and reports delivery failures. It does not supply ground-truth hazard positions to the controller.
- The **independent evaluator** uses **Gazebo world poses**, not the controller's route estimates, to measure vehicle–hazard footprint clearance, stop, resume and goal hold. The final PASS combines evaluator geometry, verified hazard motion and control-trace evidence of a true supervisor override.

This demonstrates a **distance/corridor protective stop**, not a validated TTC-based AEB algorithm. This is **SIL only**; physical R2100/CAN hardware is not used. No new physical safety claim is made.

## Run

From either of the current CAMINO checkouts, with Gazebo Harmonic and project dependencies installed:

```bash
cd ~/camino-summit-test
python3 ~/camino-safety-supervisor.zip test
python3 ~/camino-safety-supervisor.zip prepare /tmp/camino-safety-preview.sdf
python3 ~/camino-safety-supervisor.zip demo \
  --physics-step 0.002 \
  --target-rtf 1.5 \
  --wall-timeout 900
```

If the ZIP lives in the current folder, use `python3 camino-safety-supervisor.zip ...` instead. `prepare` writes a generated Gazebo world; it does **not** launch the simulation. Use `gz sim -r /tmp/camino-safety-preview.sdf` only if you want to inspect a *static preview* (the hazard driver won't move unless the demo is launched).

For two restart-separated laps, **only after an individual PASS**:

```bash
python3 ~/camino-safety-supervisor.zip loop --laps 2 \
  --physics-step 0.002 --target-rtf 1.5 --wall-timeout 900
```

## Logs and PASS checks

Every demo generates a fresh directory under `/tmp/camino-safety-.../lap` containing:

- `world.sdf` — generated world; original tracked project models stay unchanged.
- `control.jsonl` — **requested nominal speed**, **applied speed**, supervisor mode and LiDAR-observed hazard range for every tick.
- `hazard.json` — moving-obstacle pose service requests, independently confirmed Gazebo poses and completion.
- `evaluation.json` — world-pose-based clearance, stop/resume and goal evaluation.
- `result.json` — combined PASS/FAIL, failure reason, RTF and metrics.
- `safety-reports.zip` — evidence archive for follow-up analysis.

**PASS** requires the hazard actually moving across the route, at least one sequence where the supervisor overrides positive navigation speed, measured vehicle stop and subsequent motion, **at least 1 m** obstacle-footprint separation, 8° roll/pitch limits, timely route completion and an observed stationary goal hold. These are strict SIL conditions; a failed run must be diagnosed, not bypassed by weakening the safety threshold.

## Notes for the first Gazebo run

The first run is **a hypothesis test, not exhibition validation**. LiDAR visibility, the hazard's crossing schedule and the brake lead distance may need adjustments. A failure will generate reports so it can be improved without changing existing demos. Keep the original proven showcase and summit archives untouched.

## V2 pose service repair

The first live run stopped because Gazebo did not acknowledge the initial
`set_pose_vector` request. V2 retries each set-pose service, then uses the
Gazebo UserCommands single-model `set_pose` API if needed. Successful delivery
still requires **both** a positive service response and the independently
measured world pose within 0.16 m of the requested target. No safety thresholds,
route geometry, or controller logic were relaxed.

On failure, `hazard.json` now includes `last_pose_service` and
`service_request_failures`, distinguishing timeouts, negative responses and
transport exceptions. V2 must pass live Gazebo before exhibition use.
